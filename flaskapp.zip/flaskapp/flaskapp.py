from flask import Flask, request, jsonify, json
from datetime import datetime
from flask_api import status
from flask_cors import CORS, cross_origin
import werkzeug
werkzeug.cached_property = werkzeug.utils.cached_property
from recess_services import recess_services
from instamojo_payments import instamojo_payments
from chat_section import chat_section
from recess_earning_section import recess_earning_section

#------------------------------study-break----------------#
from studybreak_signup_section import signup_section
from studybreak_examsection import exam_section
from student_examsection import student_exam_section
from studybreak_class_manager import class_manager_section
#------------------------------study-break----------------#


#------------------------------urm-breaks-and-cakes----------------#
from bakes_and_cakes import bakes_and_cakes
from bakes_and_cakes_admin import bakes_and_cakes_admin
#------------------------------urm-breaks-and-cakes----------------#

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

@app.route('/')
def hello_world():
	return 'Hello, World!'
	
app.register_blueprint(recess_services, url_prefix='/recess_services')
app.register_blueprint(instamojo_payments, url_prefix='/instamojo_payments')
app.register_blueprint(chat_section, url_prefix='/chat_section')
app.register_blueprint(recess_earning_section, url_prefix='/earning_section')

#------------------------------study-break----------------#
app.register_blueprint(signup_section, url_prefix='/signup_section')
app.register_blueprint(exam_section, url_prefix='/exam_section')
app.register_blueprint(student_exam_section, url_prefix='/studentexam_section')
app.register_blueprint(class_manager_section,url_prefix='/class_manager_section')
app.register_blueprint(bakes_and_cakes, url_prefix='/bakes_and_cakes')
app.register_blueprint(bakes_and_cakes_admin, url_prefix='/bakes_and_cakes_admin')

#------------------------------study-break----------------#


if __name__ == '__main__':
	app.run()
