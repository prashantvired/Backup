from flask import Flask, request, jsonify, json
from flask_api import status
from jinja2._compat import izip
from datetime import datetime,timedelta,date
import pymysql
from flask_cors import CORS, cross_origin
from flask import Blueprint
from flask_restplus import Api, Resource, fields
from database_connections import connect_recess
import requests
import calendar
import json
from threading import Thread
import time

app = Flask(__name__)
cors = CORS(app)

recess_earning_section = Blueprint('recess_earning_section_api', __name__)
api = Api(recess_earning_section,  title='Recess API',description='Recess API')
name_space = api.namespace('Recess',description='Recess')

#---------------------------------------------------------#
earning_dtls = api.model('earning_dtls', {
	"admin_id":fields.Integer(),
	"teacher_id":fields.Integer(),
	"paid_amount":fields.Integer()
	})

bankdtls = api.model('bankdtls', {
	"user_id":fields.Integer(),
	"account_holder_name":fields.String(),
	"account_number":fields.String(),
	"ifsc_code":fields.String()
	})

teacherearning = api.model('teacherearning', {
	"teacher_id":fields.Integer(),
	"liveclass_id":fields.Integer()
	})

updateconfig = api.model('updateconfig', {
	"set_amount":fields.Integer(),
	"commission":fields.Integer()
	})

updatebankdtls = api.model('updatebankdtls', {
	"user_id":fields.Integer(),
	"account_holder_name":fields.String(),
	"account_number":fields.String(),
	"ifsc_code":fields.String()
	})

updateliveclassconfig = api.model('updateliveclassconfig', {
	"free_classes":fields.String()
	})

#---------------------------------------------------------------------------#

@name_space.route("/EarningbreakupByDateWise/<string:stdate>/<string:endate>")
class EarningbreakupByDateWise(Resource):
	def get(self,stdate,endate):
		connection = connect_recess()
		cursor = connection.cursor()
		earningbreakup = []
		details = {}
		detail = {}
		detls = {}
		dtls = {}
		dtl = {}

		cursor.execute("""SELECT Count(updated_balance)as 'total' FROM student_wallet_transaction
		 	where added_balance ='1' and 
		 	date(last_update_ts) between %s and %s""",(stdate,endate))
		earningdtls = cursor.fetchone()
		
		if earningdtls['total'] != None:
			singleclass = earningdtls['total']
			details['bundleClassname'] = 'Single Class'
			details['totalclasses'] = singleclass
			details['gross'] = singleclass*117
			details['Gst'] = 0
			details['net_pay'] = details['gross'] + details['Gst']
			earningbreakup.append(details)
		else:
			details['bundleClassname'] = 'Single Class'
			details['totalclasses'] = 0
			details['gross'] = 0
			details['Gst'] = 0
			details['net_pay'] = 0
			earningbreakup.append(details)


		cursor.execute("""SELECT Count(updated_balance)as 'total' FROM student_wallet_transaction
		 	where added_balance ='5' and 
		 	date(last_update_ts) between %s and %s""",(stdate,endate))
		fivedtls = cursor.fetchone()
		
		if fivedtls['total'] != None:
			fiveclasses = fivedtls['total']
			detail['bundleClassname'] = '5 Classes'
			detail['totalclasses'] = fiveclasses
			detail['gross'] = fiveclasses*471
			detail['Gst'] = 0
			detail['net_pay'] = detail['gross'] + detail['Gst']
			earningbreakup.append(detail)
		else:
			detail['bundleClassname'] = '5 Classes'
			detail['totalclasses'] = 0
			detaildetail['gross'] = 0
			detail['Gst'] = 0
			detail['net_pay'] = 0
			earningbreakup.append(detail)

		cursor.execute("""SELECT Count(updated_balance)as 'total' FROM student_wallet_transaction
		 	where added_balance ='10' and 
		 	date(last_update_ts) between %s and %s""",(stdate,endate))
		tendtls = cursor.fetchone()
		
		if tendtls['total'] != None:
			tenclasses = tendtls['total']
			detls['bundleClassname'] = '10 Classes'
			detls['totalclasses'] = tenclasses
			detls['gross'] = tenclasses*884
			detls['Gst'] = 0
			detls['net_pay'] = detls['gross'] + detls['Gst']
			earningbreakup.append(detls)
		else:
			detls['bundleClassname'] = '10 Classes'
			detls['totalclasses'] = 0
			detls['gross'] = 0
			detls['Gst'] = 0
			detls['net_pay'] = 0
			earningbreakup.append(detls)

		cursor.execute("""SELECT Count(updated_balance)as 'total' FROM student_wallet_transaction
		 	where added_balance ='15' and 
		 	date(last_update_ts) between %s and %s""",(stdate,endate))
		fifteendtls = cursor.fetchone()
		
		if fifteendtls['total'] != None:
			fifteenclasses = fifteendtls['total']
			dtls['bundleClassname'] = '15 Classes'
			dtls['totalclasses'] = fifteenclasses
			dtls['gross'] = fifteenclasses*1238
			dtls['Gst'] = 0
			dtls['net_pay'] = dtls['gross'] + dtls['Gst']
			earningbreakup.append(dtls)
		else:
			dtls['bundleClassname'] = '15 Classes'
			dtls['totalclasses'] = 0
			dtls['gross'] = 0
			dtls['Gst'] = 0
			dtls['net_pay'] = 0
			earningbreakup.append(dtls)
			

		cursor.execute("""SELECT Count(updated_balance)as 'total' FROM student_wallet_transaction
		 	where added_balance ='unlimited' and 
		 	date(last_update_ts) between %s and %s""",(stdate,endate))
		unlimiteddtls = cursor.fetchone()
		
		if unlimiteddtls['total'] != None:
			unlimitedclasses = unlimiteddtls['total']
			dtl['bundleClassname'] = 'unlimited'
			dtl['totalclasses'] = unlimitedclasses
			dtl['gross'] = unlimitedclasses*4719
			dtl['Gst'] = 0
			dtl['net_pay'] = dtl['gross'] + dtl['Gst']
			earningbreakup.append(dtl)
		else:
			dtl['bundleClassname'] = 'unlimited'
			dtl['totalclasses'] = 0
			dtl['gross'] = 0
			dtl['Gst'] = 0
			dtl['net_pay'] = 0
			earningbreakup.append(dtl)

		
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Earning BreakUp Details",
                                "status": "success"
                                },
                 "responseList": earningbreakup }), status.HTTP_200_OK

#------------------------------------------------------------#
@name_space.route("/TeacherEarningDtlsByDateTeacherId/<int:teacher_id>/<string:stdate>/<string:endate>")
class TeacherEarningDtlsByDateTeacherId(Resource):
	def get(self,teacher_id,stdate,endate):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()
		earning = {}
		details = []
		detail = []

		cursor.execute("""SELECT previous_amount,updated_amount FROM teacher_payment_wallet 
			where admin_id!=0 and date(`last_update_ts`) between %s and %s""",(stdate,endate))
		paidamntDtls = cursor.fetchone()

		if paidamntDtls:
			paidamnt = paidamntDtls['updated_amount']
			prevpayable = paidamntDtls['previous_amount']
			netpayout = prevpayable - paidamnt

		else:
			paidamnt = 0

		cursor.execute("""SELECT Student_ID,liveclass_id FROM 
			`student_liveclass_tracking` where Student_ID=%s and 
			date(last_update_ts) between %s and %s""",(teacher_id,stdate,endate))
		trkclassDtls = cursor.fetchall()
		if trkclassDtls:
			cursor.execute("""SELECT liveclass_id FROM liveclass_mapping 
				where teacher_id=%s and date(`start_date`) between %s 
				and %s""",(teacher_id,stdate,endate))
			liveclassDtls = cursor.fetchall()

			for i in range(len(liveclassDtls)):
				cursor.execute("""SELECT count(student_id)as 'count' FROM 
					liveclass_student_mapping where `liveclass_id`=%s""",
					(liveclassDtls[i]['liveclass_id']))
				countDtls = cursor.fetchone()

				if countDtls['count'] != None:
					if countDtls['count'] > 2:
						detail.append(liveclassDtls[i]['liveclass_id'])
						registered = countDtls['count']
						details.append(registered)
						totalregNo = sum(details)

					cursor.execute("""SELECT set_amount,bonus,commission,
						tax,other_deduction FROM configuration""")
					configdtls = cursor.fetchone()

					fixedpay = configdtls['set_amount']
					variablepay = configdtls['commission']*totalregNo
					bonus = configdtls['bonus']
					tax = configdtls['tax']
					other_deduction = configdtls['other_deduction']
					commission = configdtls['commission']
					nettobepaid = fixedpay + variablepay + bonus + tax + other_deduction
					
					earning['no_of_classes'] = len(detail)
					earning['registered_no'] = totalregNo
					earning['bonus'] = bonus
					earning['tax'] = tax
					earning['commission'] = commission
					earning['basic_pay'] = fixedpay
					earning['tobepaid'] = paidamnt
					earning['netpayout'] = netpayout
		else:
			earning['no_of_classes'] = 0
			earning['registered_no'] = 0
			earning['bonus'] = 0
			earning['tax'] = 0
			earning['commission'] = 0
			earning['basic_pay'] = 0
			earning['tobepaid'] = 0
			earning['netpayout'] = 0

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Earning BreakUp Details",
                                "status": "success"
                                },
                 "responseList": earning }), status.HTTP_200_OK

#--------------------------------------------------------#
@name_space.route("/AddAdminPayoutDetails")
class AddAdminPayoutDetails(Resource):
	@api.expect(earning_dtls)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		admin_id = details.get('admin_id') 
		teacher_id = details.get('teacher_id') 
		paid_amount = details.get('paid_amount') 
		
		cursor.execute("""SELECT `previous_amount`,`updated_amount` 
			FROM `teacher_payment_wallet` WHERE `teacher_id`=%s 
			ORDER BY `transaction_id` DESC""",(teacher_id))
		wallettrnsDtls = cursor.fetchone()
		# print(wallettrnsDtls)
		if wallettrnsDtls:
			previous_amount = wallettrnsDtls.get('updated_amount')
			updated_amount = previous_amount - paid_amount

			teapaywalletQuery = ("""INSERT INTO `teacher_payment_wallet`(teacher_id,
				`admin_id`,`previous_amount`,`updated_amount`) 
				VALUES (%s,%s,%s,%s)""")
			
			teapaywalletData = cursor.execute(teapaywalletQuery,(teacher_id,
				admin_id,previous_amount,updated_amount))

			payoutQuery = ("""INSERT INTO `admin_payout`(`admin_id`,
				`teacher_id`,`paid_amount`) VALUES (%s,%s,%s)""")
			
			payoutData = cursor.execute(payoutQuery,(admin_id,
				teacher_id,paid_amount))

			msg = "Added"

		else:
			msg = "Not Added"

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Admin Payout Details",
                                "status": "success",
                                "msg": msg
                                },
	             "responseList": details}), status.HTTP_200_OK
		
#---------------------------------------------------------------------------#
@name_space.route("/AdminPayoutDtlsByDatewise/<string:stdate>/<string:endate>")
class AdminPayoutDtlsByDatewise(Resource):
	def get(self,stdate,endate):
		connection = connect_recess()
		cursor = connection.cursor()
		payout = []
		details = []
		detail = []

		cursor.execute("""SELECT `liveclass_id`,teacher_id FROM 
			liveclass_mapping where date(`start_date`) between %s and
			%s""",(stdate,endate))
		liveDtls = cursor.fetchall()
		
		if liveDtls !=():
			for lcid in range(len(liveDtls)):
				detail.append(liveDtls[lcid]['teacher_id'])
			tid = set(detail)
			
			cursor.execute("""SELECT `user_id` as 'teacher_id',
				CONCAT(first_name, ' ' , middle_name, ' ' , last_name)as 'teachername',
				phone_no,updated_amount as 'tobepaid',tpw.`last_update_ts`
				FROM teacher_payment_wallet tpw inner join `user_credential` uc
			 	on tpw.`teacher_id`=uc.`user_id` where teacher_id in %s and
			 	date(tpw.`last_update_ts`) between %s and %s ORDER BY `transaction_id` DESC""",
			 	(tid,stdate,endate))
			paiddtls = cursor.fetchone()
			if paiddtls:
				
				paiddtls['last_update_ts'] = paiddtls['last_update_ts'].isoformat()
				details.append(paiddtls['tobepaid'])
				
				myset = set(details)	
				Sum = sum(myset)
				totaltobepaid = Sum
				payout.append(paiddtls)
			else:
				totaltobepaid = 0
				payout = []
		else:
			totaltobepaid = 0
			payout = []

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Payout Details",
                                "status": "success",
                                "totaltobepaid":totaltobepaid
                                },
                 "responseList": payout }), status.HTTP_200_OK

#-------------------------------------------------------------#
@name_space.route("/AddBankDetails")
class AddBankDetails(Resource):
	@api.expect(bankdtls)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		user_id = details.get('user_id') 
		account_holder_name = details.get('account_holder_name') 
		account_number = details.get('account_number')
		ifsc_code = details.get('ifsc_code') 
		
		cursor.execute("""SELECT `user_id`,CONCAT(first_name, ' ' , middle_name, ' ' , last_name)as name,
			`email_id`,`phone_no`,`password` FROM `user_credential` 
			WHERE `user_id`=%s""",(user_id))
		userCredentialDtls = cursor.fetchone()

		if userCredentialDtls:
			
			bankdtlsQuery = ("""INSERT INTO `razor_user_dtls`(user_id,
				`mail_id`,`username`,`password`,phoneno,account_holder_name,
				account_number,ifsc_code) 
				VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""")
			
			bankdtlsData = cursor.execute(bankdtlsQuery,(user_id,
				userCredentialDtls['email_id'],userCredentialDtls['name'],
				userCredentialDtls['password'],userCredentialDtls['phone_no'],
				account_holder_name,account_number,ifsc_code))

			if bankdtlsData:
				msg = "Added"
			else:
				msg = "Not Added"
		else:
			msg = "Not Exists"

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "User Bank Details",
                                "status": "success",
                                "msg": msg
                                },
	             "responseList": details}), status.HTTP_200_OK

#--------------------------------------------------------#
@name_space.route("/UserBankDtlsByUserId/<int:user_id>")
class UserBankDtlsByUserId(Resource):
	def get(self,user_id):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT rud.`user_id`,CONCAT(first_name, ' ' , middle_name, ' ' , last_name)as name,
			`email_id`,`phone_no`,rud.`password`,account_holder_name,account_number,
			ifsc_code FROM `razor_user_dtls` rud inner join `user_credential` uc
			on rud.`user_id`=uc.`user_id` where rud.`user_id`=%s""",(user_id))
		bankDtls = cursor.fetchone()
		
		if bankDtls:
			userbankDtls = bankDtls
			
		else:
			userbankDtls = {}

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "User Bank Details",
                                "status": "success"
                                },
                 "responseList": userbankDtls }), status.HTTP_200_OK
		
#--------------------------------------------------------#
@name_space.route("/RecessNetEarningDtlsByDateWise/<string:stdate>/<string:endate>")
class RecessNetEarningDtlsByDateWise(Resource):
	def get(self,stdate,endate):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT SUM(amount)as 'total' FROM razorpay_payment_dtls
		 	where date(last_update_ts) between %s and %s""",(stdate,endate))
		earningdtls = cursor.fetchone()
		
		if earningdtls['total'] != None:
			netearning = int(earningdtls['total'])
			
		else:
			netearning = 0

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Recess Net Earning Details",
                                "status": "success"
                                },
                 "responseList": netearning }), status.HTTP_200_OK

#--------------------------------------------------------#
@name_space.route("/PaymentTransactionByAdminId/<int:admin_id>")
class PaymentTransactionByAdminId(Resource):
	def get(self,admin_id):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT ap.`admin_id`,teacher_id,
			CONCAT(first_name, ' ' , middle_name, ' ' , last_name)as 
			'teachername',phone_no,paid_amount,ap.`last_update_ts` FROM 
			admin_payout ap inner join `user_credential` uc on ap.`teacher_id`=uc.`user_id`
			where ap.`admin_id`=%s""",(admin_id))
		transacdtls = cursor.fetchall()
		
		if transacdtls:
			for i in range(len(transacdtls)):
				transacdtls[i]['last_update_ts'] = transacdtls[i]['last_update_ts'].isoformat()
			
		else:
			transacdtls = []

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Payment Transaction Details",
                                "status": "success"
                                },
                 "responseList": transacdtls }), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/TeacherEarning")
class TeacherEarning(Resource):
	@api.expect(teacherearning)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		teacher_id = details.get('teacher_id') 
		liveclass_id = details.get('liveclass_id')
		
		cursor.execute("""SELECT count(student_id)as 'count' FROM 
			liveclass_student_mapping where `liveclass_id`=%s""",(liveclass_id))
		countDtls = cursor.fetchone()

		if countDtls['count'] != None:
			if countDtls['count'] > 2:
				
				cursor.execute("""SELECT `previous_amount`,`updated_amount` 
					FROM `teacher_payment_wallet` WHERE `teacher_id`=%s 
					ORDER BY `transaction_id` DESC""",(teacher_id))
				wallettrnsDtls = cursor.fetchone()
				if wallettrnsDtls:
					previous_amount = wallettrnsDtls['updated_amount']

					cursor.execute("""SELECT set_amount,bonus,commission,
						tax,other_deduction FROM configuration""")
					configdtls = cursor.fetchone()

					fixedpay = configdtls['set_amount']
					variablepay = configdtls['commission']*totalregNo
					
					updated_amnt = previous_amount + fixedpay + variablepay

					teapaywalletQuery = ("""INSERT INTO `teacher_payment_wallet`(teacher_id,
						`previous_amount`,`updated_amount`) VALUES (%s,%s,%s)""")
					
					teapaywalletData = cursor.execute(teapaywalletQuery,(teacher_id,
						previous_amount,updated_amnt))

					if teapaywalletData:
						msg = "Added"
					else:
						msg = "Added"
				else:
					previous_amount = 0

					cursor.execute("""SELECT set_amount,bonus,commission,
						tax,other_deduction FROM configuration""")
					configdtls = cursor.fetchone()

					fixedpay = configdtls['set_amount']
					variablepay = configdtls['commission']*totalregNo
					
					updated_amnt = previous_amount + fixedpay + variablepay
					
					teapaywalletQuery = ("""INSERT INTO `teacher_payment_wallet`(teacher_id,
						`previous_amount`,`updated_amount`) VALUES (%s,%s,%s)""")
					
					teapaywalletData = cursor.execute(teapaywalletQuery,(teacher_id,
						previous_amount,updated_amnt))

					if teapaywalletData:
						msg = "Added"
					else:
						msg = "Added"
			else:
				msg = "Atleast 3 students have to register"

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Teacher Earning Details",
                                "status": "success",
                                "msg": msg
                                },
	             "responseList": details}), status.HTTP_200_OK
		
#--------------------------------------------------------#
@name_space.route("/ConfigurationDetails")
class ConfigurationDetails(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT config_id,set_amount,bonus,
			commission,tax,other_deduction FROM configuration""")
		configdtls = cursor.fetchone()

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Configuration Details",
                                "status": "success"
                                },
                 "responseList": configdtls }), status.HTTP_200_OK
		
#--------------------------------------------------------#
@name_space.route("/UpdateConfiguration")	
class UpdateConfiguration(Resource):
	@api.expect(updateconfig)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		Set_amount = details.get('set_amount')
		Commission = details.get('commission')

		cursor.execute("""SELECT set_amount,bonus,commission,
			tax,other_deduction FROM configuration""")
		configdtls = cursor.fetchone()

		if configdtls:
		
			if not Set_amount:
				Set_amount = configdtls.get('set_amount')

			if not Commission:
				Commission = configdtls.get('commission')

		update_status = ("""UPDATE `configuration` SET 
			set_amount=%s,commission=%s""")
		updatedata = cursor.execute(update_status,(Set_amount,Commission))

		if updatedata:
			msg = "Configuration Updated"
		else:
			msg = "Not Updated"

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Update Configuration Details",
                            "status": "success",
                            "msg": msg
                            },
                "responseList":details}), status.HTTP_200_OK

#-------------------------------------------------------------#
@name_space.route("/UpdateUserBankDetails")	
class UpdateUserBankDetails(Resource):
	@api.expect(updatebankdtls)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		user_id = details.get('user_id') 
		Account_holder_name = details.get('account_holder_name') 
		Account_number = details.get('account_number')
		Ifsc_code = details.get('ifsc_code') 

		cursor.execute("""SELECT `user_id`,account_holder_name,
			account_number,ifsc_code FROM `razor_user_dtls` 
			where `user_id`=%s""",(user_id))
		bankDtls = cursor.fetchone()
		
		if bankDtls:

			if not Account_holder_name:
				Account_holder_name = bankDtls.get('account_holder_name')

			if not Account_number:
				Account_number = bankDtls.get('account_number')

			if not Ifsc_code:
				Ifsc_code = bankDtls.get('ifsc_code')

		update_status = ("""UPDATE `razor_user_dtls` SET 
			account_holder_name=%s,account_number=%s,ifsc_code=%s 
			where `user_id`=%s""")
		updatedata = cursor.execute(update_status,(Account_holder_name,
			Account_number,Ifsc_code,user_id))

		if updatedata:
			msg = "Bank Details Updated"
		else:
			msg = "Not Updated"

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Update User Bank Details",
                            "status": "success",
                            "msg": msg
                            },
                "responseList":details}), status.HTTP_200_OK
		
#--------------------------------------------------------#
@name_space.route("/FreeLiveClassConfigurationDetails")
class FreeLiveClassConfigurationDetails(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT free_config_id,free_classes
			FROM free_liveclass_configuration""")
		configdtls = cursor.fetchone()

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Free Live Class Configuration Details",
                                "status": "success"
                                },
                 "responseList": configdtls }), status.HTTP_200_OK
		
#--------------------------------------------------------#
@name_space.route("/UpdateFreeLiveClassConfiguration")	
class UpdateFreeLiveClassConfiguration(Resource):
	@api.expect(updateliveclassconfig)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		free_classes = details.get('free_classes')

		update_status = ("""UPDATE `free_liveclass_configuration` SET 
			free_classes=%s""")
		updatedata = cursor.execute(update_status,(free_classes))

		if updatedata:
			msg = "Configuration Updated"
		else:
			msg = "Not Updated"

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Live Class Configuration Details",
                            "status": "success",
                            "msg": msg
                            },
                "responseList":details}), status.HTTP_200_OK

#-------------------------------------------------------------#
		
