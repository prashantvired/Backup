from flask import Flask, request, jsonify, json
from flask_api import status
from jinja2._compat import izip
from datetime import datetime, timedelta,date
import pymysql
from flask_cors import CORS, cross_origin
from flask import Blueprint
from flask_restplus import Api, Resource, fields
from database_connections import connect_recess
from pytz import timezone
from time import strftime
import pytz
import requests
import calendar
import json
from threading import Thread
import time


app = Flask(__name__)
cors = CORS(app)

recess_services = Blueprint('recess_api', __name__)
api = Api(recess_services,  title='Recess API',description='Recess API')
name_space = api.namespace('Recess',description='Recess')


usersignup = api.model('usersignup', {
	"name":fields.String(),
	"user_role":fields.String(),
	"email_id":fields.String(),
	"phone_no":fields.Integer(),
	"password":fields.String(),
	"exam":fields.String(),
	"experience":fields.String(),
	"qualification":fields.String(),
	"videolink":fields.String()
    })

usercontact = api.model('usercontact', {
	"phone_no":fields.Integer(),
	"email_id":fields.String()
    })

usersignin = api.model('usersignin', {
	"phone_no":fields.Integer(),
	"email_id":fields.String(),
	"password":fields.String(),
	"social_flag":fields.String()
    })

adminsignin = api.model('adminsignin', {
	"phone_no":fields.Integer(),
	"password":fields.String()
    })

createCourse = api.model('createCourse', {
	"course_title":fields.String(),
	"course_starting":fields.String(),
	"course_ending":fields.String(),  
	"content_name":fields.String(),
	"content_description":fields.String(),
	"course_image":fields.String(),
	"course_filetype":fields.String(),
	"teacher_id":fields.Integer(),
	"exam":fields.String()
	})

updatecourse_Status =  api.model('updatecourse_Status', {
	"course_id":fields.Integer(),
	"admin_id":fields.Integer(),
	"flag": fields.String()
	})

updateteacher_Status =  api.model('updateteacher_Status', {
	"teacher_id":fields.Integer(),
	"admin_id":fields.Integer(),
	"flag": fields.String()
	})

uploadvideos = api.model('uploadvideos', {
	"content_name":fields.String(),
	"co_contentname":fields.String(),
	"content_filepath":fields.String(),
	"content_filename":fields.String(),
	"content_filetype":fields.String(),
	"teacher_id":fields.Integer(),
	"exam":fields.String()
	})

create_meeting = api.model('create_meeting', {
	"teacher_id":fields.Integer(),
	"course_id":fields.Integer(),
	"start_date":fields.String(), 
	"duration":fields.Integer(),
	"topic":fields.String()
	})

create_payment_dtls_model = api.model('create_payment_dtls_model', {
	"student_id":fields.Integer(),
	"liveclass_id":fields.Integer(),
	"payment_mode":fields.String(),
	"payment_type":fields.String(),
	"total_amount":fields.String(),
	})

addImageurl =  api.model('addImageurl', {
	"imageurl":fields.String(),
	"user_id":fields.Integer()
	})

liveclassDtls = api.model('liveclassDtls', {
	"liveclass_id":fields.Integer()
	})

register_liveclass = api.model('register_liveclass', {
	"student_id":fields.Integer(),
	"no_of_class":fields.Integer(),
	"liveclassDtls":fields.List(fields.Nested(liveclassDtls))
	})

liveclasstracking = api.model('liveclasstracking', {
	"Student_ID":fields.Integer(),
	"liveclass_id":fields.Integer(),
	"Duration":fields.Integer(),
	"Status":fields.String()
	})

update_profile = api.model('update_profile', {
	"user_id":fields.Integer(),
	"name":fields.String(),
	"email_id":fields.String(),
	"phone_no":fields.Integer(),
	"password":fields.String(),
	"exam":fields.String(),
	"imageurl":fields.String(),
	"experience":fields.String(),
	"qualification":fields.String(),
	"videolink":fields.String()
    })

zoomdtls = api.model('zoomdtls', {
	"user_phoneno":fields.String(),
	"email_id":fields.String(),
	"zoom_password":fields.String(),
	"zoom_api_key":fields.String()
	})

BASE_URL = "http://ec2-18-191-151-105.us-east-2.compute.amazonaws.com/flaskapp/"

#---------------------------------------------------------------------------#
@name_space.route("/SignUp")
class SignUp(Resource):
	@api.expect(usersignup)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		name = details.get('name')
		user_role = details.get('user_role')
		email_id = details.get('email_id')
		ph_no = details.get('phone_no')
		password = details.get('password')
		exam = details.get('exam')
		experience = details.get('experience')
		qualification = details.get('qualification')
		videolink = details.get('videolink')
			
		if len(name.split(" ")) < 2:
			first_name = name
			middle_name = ''
			last_name = ''
			
		elif len(name.split(" ")) == 2:
			parsed_name = name.split(" ", 1)
			first_name = parsed_name[0]
			middle_name = ''
			last_name = parsed_name[1]
			
		else:
			parsed_name = name.split(" ", 2)
			first_name = parsed_name[0]
			middle_name = parsed_name[1]
			last_name = parsed_name[2]
			
		cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
			`user_role`,`email_id`,`phone_no`,`password`,`exam` FROM 
			`user_credential` WHERE `phone_no`=%s or `email_id`=%s""",
			(ph_no,email_id))
		userCredentialDtls = cursor.fetchone()

		if userCredentialDtls == None:
			if user_role == 'T1':
				credential_query = ("""INSERT INTO `user_credential`(`first_name`, 
					`middle_name`, `last_name`, `user_role`,`flag`,`email_id`, `phone_no`, 
					`password`, `exam`,`experience`,`qualification`,`videolink`)VALUES 
					(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""")
				credential_data = (first_name,middle_name,last_name,user_role,'Pending',
					email_id,ph_no,password,exam,experience,qualification,videolink)
				credentialdata = cursor.execute(credential_query,credential_data)

				teacher_id = cursor.lastrowid
				details['user_id'] = teacher_id

			if user_role == 'S1':
				credential_query = ("""INSERT INTO `user_credential`(`first_name`, 
					`middle_name`, `last_name`, `user_role`,`flag`,`email_id`, `phone_no`, 
					`password`, `exam`,`experience`,`qualification`,`videolink`)VALUES 
					(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""")
				credential_data = (first_name,middle_name,last_name,user_role,'',
					email_id,ph_no,password,exam,experience,qualification,videolink)
				credentialdata = cursor.execute(credential_query,credential_data)

				student_id = cursor.lastrowid
				details['user_id'] = student_id

				cursor.execute("""SELECT free_classes FROM 
					free_liveclass_configuration""")
				configdtls = cursor.fetchone()

				if configdtls:
					wallet_query = ("""INSERT INTO `student_wallet`(student_id,
					    update_amount)VALUES (%s,%s)""")
					wallet_data = (student_id,configdtls['free_classes'])
					walletdata = cursor.execute(wallet_query,wallet_data)

					transQuery = ("""INSERT INTO `student_wallet_transaction`(`student_id`,
						`previous_balance`,`added_balance`,`updated_balance`) VALUES (%s,
						%s,%s,%s)""")
					
					transData = cursor.execute(transQuery,(student_id,0,
						configdtls['free_classes'],configdtls['free_classes']))

			connection.commit()
			cursor.close()

			return ({"attributes": {"status_desc": "User Signup Details",
	                                "status": "success"
		                                },
		             "responseList": details}), status.HTTP_200_OK
		else:
			return ({"attributes": {"status_desc": "User Signup Details",
	                                "status": "not success"
		                                },
		             "responseList": "Already Registered Email Id Or Phone No"}), status.HTTP_200_OK

#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#			
@name_space.route("/VerifyUserPhoneNoOrEmailId")
class VerifyUserPhoneNoOrEmailId(Resource):
	@api.expect(usercontact)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		phone_no = details.get('phone_no')
		email_id = details.get('email_id')

		if phone_no:
			cursor.execute("""SELECT `user_id` FROM `user_credential` WHERE 
				`phone_no`=%s""",(phone_no))
			userPhonenoExists = cursor.fetchone()
			if userPhonenoExists:
				
				return ({"attributes": {
										"status_desc": "Verify User Phone Number",
										"status": "success"
										},
				"responseList": "Exists"}), status.HTTP_200_OK
				
			else:
				return ({"attributes": {"status_desc": "Verify User Phone Number",
									"status": "success"
									},
					"responseList": "Not Exists"}), status.HTTP_200_OK
		else:
			cursor.execute("""SELECT `user_id` FROM `user_credential` WHERE 
				`email_id`=%s""",(email_id))
			userPhonenoExists = cursor.fetchone()
			if userPhonenoExists:
				
				return ({"attributes": {
										"status_desc": "Verify User Email Id",
										"status": "success"
										},
				"responseList": "Exists"}), status.HTTP_200_OK
		
				
			else:
				return ({"attributes": {"status_desc": "Verify User Email Id",
									"status": "success"
									},
					"responseList": "Not Exists"}), status.HTTP_200_OK
			
#---------------------------------------------------------------------------#


#---------------------------------------------------------------------------#
@name_space.route("/SignIn")
class Signin(Resource):
	@api.expect(usersignin)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		phone_no = details.get('phone_no')
		email_id = details.get('email_id')
		password = details.get('password')
		social_flag = details.get('social_flag')
		
		if phone_no != '' and social_flag == "1" and email_id == "" and password == "":
			cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				`flag`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,
				`experience`,`qualification`,`videolink`,`imageurl` FROM `user_credential` WHERE 
				`phone_no`=%s""",(phone_no))
			userCredentialDtls = cursor.fetchone()
			if userCredentialDtls:
				userCredentialDtls['social_flag'] = "1"
				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
										},
				"responseList": userCredentialDtls}), status.HTTP_200_OK
		
		elif phone_no != '' and password != '' and social_flag == None and email_id == "":
			cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				`flag`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,
				`experience`,`qualification`,`videolink`,`imageurl` FROM `user_credential` WHERE 
				`phone_no`=%s and `password`=%s""",(phone_no,password))
			userCredentialDtls = cursor.fetchone()
			if userCredentialDtls:

				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
										},
				"responseList": userCredentialDtls}), status.HTTP_200_OK
		
			else:
				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
									},
					"responseList": "Invalid Password"}), status.HTTP_200_OK

		elif email_id != '' and social_flag == "1" and phone_no == 0 and password == "":
			cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				`flag`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,`experience`,
				`qualification`,`videolink`,`imageurl` FROM `user_credential` WHERE 
				`email_id`=%s""",(email_id))
			userCredentialDtls = cursor.fetchone()
			if userCredentialDtls:
				userCredentialDtls['social_flag'] = "1"
				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
										},
				"responseList": userCredentialDtls}), status.HTTP_200_OK
		
		else:
			cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				`flag`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,`experience`,
				`qualification`,`videolink`,`imageurl` FROM `user_credential` WHERE 
				`email_id`=%s and `password`=%s""",(email_id,password))
			userCredentialDtls = cursor.fetchone()
			if userCredentialDtls:
				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
										},
				"responseList": userCredentialDtls}), status.HTTP_200_OK
		
			else:
				return ({"attributes": {
										"status_desc": "User Signin Details",
										"status": "success"
									},
					"responseList": "Invalid Password"}), status.HTTP_200_OK
			
			
#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#
@name_space.route("/CreateCourse")
class CreateCourse(Resource):
	@api.expect(createCourse)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		course_title = details.get('course_title')
		course_starting = details.get('course_starting')
		course_ending = details.get('course_ending')
		content_name = details.get('content_name')
		content_description = details.get('content_description')
		course_image = details.get('course_image')
		course_filetype = details.get('course_filetype')
		teacher_id = details.get('teacher_id')
		exam = details.get('exam')

		if course_image == '' or course_filetype == '':
			course_image = ''
			course_filetype = ''
		else:
			course_image = course_image
			course_filetype = course_filetype

		cursor.execute("""SELECT  `course_title` FROM `course_master` WHERE 
			`course_title`=%s""",(course_title))
		courseTitle = cursor.fetchone()

		if courseTitle == None:

			course_query = ("""INSERT INTO `course_master`(`course_title`, 
				`course_starting`, `course_ending`, `flag`, `content_name`, 
				`content_description`, `course_image`, `course_filetype`, 
				`teacher_id`, `exam`, `last_update_id`)VALUES (%s,%s,%s,%s,%s,
				%s,%s,%s,%s,%s,%s)""")
			course_data = (course_title,course_starting,course_ending,
				'Pending',content_name,content_description,course_image,
				course_filetype,teacher_id,exam,teacher_id)
			coursedata = cursor.execute(course_query,course_data)

			course_id = cursor.lastrowid
			details['course_id'] = course_id
			connection.commit()
			cursor.close()

			return ({"attributes": {"status_desc": "Course Added",
	                                "status": "success"
		                                },
		             "responseList": details}), status.HTTP_200_OK
		else:
			return ({"attributes": {"status_desc": "Course Added",
	                                "status": "not success"
		                            },
		             "responseList": "Already Exists Course Title"}), status.HTTP_200_OK

#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#
@name_space.route("/LiveClassPriceList")
class LiveClassPriceList(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `price_id`, `no_of_liveclass`, `amount`,`GST`,
			`total_amount` FROM `liveclass_price_dtls`""")
		Pricedtls = cursor.fetchall()

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Live Class Price Details",
                                "status": "success"
                                },
                 "responseList": Pricedtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#
@name_space.route("/CourseListByTeacherId/<int:teacher_id>")
class CourseListByTeacherId(Resource):
	def get(self,teacher_id):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `course_id`, `course_title`, 
			`course_starting`, `course_ending`, `flag`, `admin_id`, 
			`content_name`, `content_description`, `course_image`, 
			`course_filetype`, `teacher_id`, `exam`,  `last_update_id`, 
			`last_update_ts` FROM `course_master` WHERE `teacher_id`=%s and
			`flag`='Pending'""",(teacher_id))
		PendingCoursedtls = cursor.fetchall()
		# print(PendingCoursedtls)
		if PendingCoursedtls:
			for i in range(len(PendingCoursedtls)):
				PendingCoursedtls[i]['course_starting'] = PendingCoursedtls[i]['course_starting'].isoformat()
				PendingCoursedtls[i]['course_ending'] = PendingCoursedtls[i]['course_ending'].isoformat()
				PendingCoursedtls[i]['last_update_ts'] = PendingCoursedtls[i]['last_update_ts'].isoformat()
		else:
			[]

		cursor.execute("""SELECT `course_id`, `course_title`, 
			`course_starting`, `course_ending`, `flag`, `admin_id`, 
			`content_name`, `content_description`, `course_image`, 
			`course_filetype`, `teacher_id`, `exam`,  `last_update_id`, 
			`last_update_ts` FROM `course_master` WHERE `teacher_id`=%s and
			`flag`='Approved'""",(teacher_id))
		ApprovedCoursedtls = cursor.fetchall()
		# print(ApprovedCoursedtls)
		if ApprovedCoursedtls:

			for i in range(len(ApprovedCoursedtls)):
				ApprovedCoursedtls[i]['course_starting'] = ApprovedCoursedtls[i]['course_starting'].isoformat()
				ApprovedCoursedtls[i]['course_ending'] = ApprovedCoursedtls[i]['course_ending'].isoformat()
				ApprovedCoursedtls[i]['last_update_ts'] = ApprovedCoursedtls[i]['last_update_ts'].isoformat()
		else:
			[]

		Coursedtls = {
				"pendingCourse":PendingCoursedtls,
				"approvedCourse":ApprovedCoursedtls
			}
		
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Course List",
                                "status": "success"
                                },
                 "responseList": Coursedtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#
@name_space.route("/UploadVideos")
class UploadVideos(Resource):
	@api.expect(uploadvideos)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		content_name = details.get('content_name')
		co_contentname = details.get('co_contentname')  
		content_filepath = details.get('content_filepath') 
		content_filename = details.get('content_filename') 
		content_filetype = details.get('content_filetype') 
		teacher_id = details.get('teacher_id') 
		exam = details.get('exam') 
		
		content_query = ("""INSERT INTO `content_library`(`content_name`, `co_contentname`,
			`content_filepath`, `content_filename`, `content_filetype`,
			`exam`, `teacher_id`, `last_update_id`) VALUES (%s,%s,%s,%s,%s,
			%s,%s,%s)""")
		content_data = (content_name,co_contentname,content_filepath,
			content_filename,content_filetype,exam,teacher_id,teacher_id)
		contentdata = cursor.execute(content_query,content_data)

		content_id = cursor.lastrowid
		details['content_id'] = content_id
		connection.commit()
		cursor.close()

		if contentdata:
			
			return ({"attributes": {"status_desc": "Video Added",
                                "status": "success"
	                                },
	             "responseList": details}), status.HTTP_200_OK
		
		else:
			return ({"attributes": {"status_desc": "Video Added",
                                "status": "notsuccess"
	                                },
	             "responseList": []}), status.HTTP_200_OK
		
#---------------------------------------------------------------------------#

#---------------------------------------------------------------------------#
@name_space.route("/getContentListByExam/<string:exam>")
class getContentListByExam(Resource):
	def get(self,exam):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT content_id,content_name,co_contentname,
			content_filepath,content_filename,content_filetype,exam,
			teacher_id FROM content_library where exam=%s""",(exam))
		Contentdtls = cursor.fetchall()
		for i in range(len(Contentdtls)):
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
				as 'name',imageurl FROM `user_credential`where user_id=%s""",(Contentdtls[i]['teacher_id']))
			teacherdtls = cursor.fetchone()
			if teacherdtls:
				teachername = teacherdtls['name']
				imageurl = teacherdtls['imageurl']
				Contentdtls[i]['teachername'] = teachername
				Contentdtls[i]['imageurl'] = imageurl
			else:
				teachername = ''
				imageurl = ''
				Contentdtls[i]['teachername'] = teachername
				Contentdtls[i]['imageurl'] = imageurl
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Content Details",
                                "status": "success"
                                },
                 "responseList": Contentdtls}), status.HTTP_200_OK

#--------------------------------------------------------------------#
@name_space.route("/scheduleLiveClass")
class createZoomMeeting(Resource):
	@api.expect(create_meeting)
	def post(self):

		connection = connect_recess()
		cursor = connection.cursor()

		details = request.get_json()
		teacher_id = details.get('teacher_id')
		course_id = details.get('course_id')
		start_date = details.get('start_date') 
		duration = details.get('duration')
		topic = details.get('topic')

		res = {}
		
		cursor.execute("""SELECT `user_mailid`,`zoom_api_key` FROM `zoom_user_details` 
			WHERE `user_id` =2""")

		teacherDtls = cursor.fetchone()

		if teacherDtls:

			mailId = teacherDtls.get('user_mailid')
			apiKey = teacherDtls.get('zoom_api_key')

			start_time = details['start_date']
			
			cursor.execute("""SELECT `content_name`, `content_description` 
				FROM `course_master` WHERE `course_id`=%s and 
				flag='Approved'""",(course_id))

			courseDtls = cursor.fetchone()

			if courseDtls:
				cursor.execute("""SELECT * FROM liveclass_mapping where 
					start_date=%s""",(start_time))

				existsliveclass = cursor.fetchone()
				if existsliveclass:
					message = 'Please Try another date/time to Schedule liveclass'
				else:
					headers = {'Content-Type':'application/json','authorization': 'Bearer ' + apiKey}
					createUrl = 'https://api.zoom.us/v2/users/{userId}/meetings'.format(userId=mailId)
					zoom_payload = {"topic": topic,
									"type": 2,
									"start_time": start_time,
									"duration": 40,
									"timezone": "Asia/Calcutta",
									"password": "",
									"agenda": courseDtls['content_description'],
									"settings": {
										"host_video": "true",
										"participant_video": "false",
										"join_before_host": "true",
										"mute_upon_entry": "true",
										"watermark": "true",
										"use_pmi": "false",
										"approval_type": "2",
										"registration_type": "1",
										"audio": "both",
										"auto_recording": "local"
										}
									}

					postRequest = requests.post(createUrl, data=json.dumps(zoom_payload), headers=headers)
					postStatus = postRequest.status_code
					# print(postStatus)
					
					if postStatus == 201:
						postRes = postRequest.json()
						zoom_meeting_id = postRes.get('id')
						zoom_uuid = postRes.get('uuid')
						zoom_join_url = postRes.get('join_url')

						createMeetingQuery = ("""INSERT INTO `liveclass_mapping`(`course_id`,
							`zoom_meeting_id`, `zoom_uuid`, `zoom_join_url`, `teacher_id`, 
							`platform`,`start_date`,`duration`,`topic`) 
							VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""")

						meetingData = (course_id,zoom_meeting_id,zoom_uuid,
							zoom_join_url,teacher_id,'zoom',start_time,duration,
							topic)

						cursor.execute(createMeetingQuery,meetingData)
						liveclass_id = cursor.lastrowid
						res = {'zoom_meeting_id':zoom_meeting_id,
								'zoom_uuid':zoom_uuid,
								'zoom_join_url':zoom_join_url}
						message = 'Zoom Meeting Scheduled Successfully'
						
					else:
						message = 'Failed to Schedule Zoom Meeting Scheduled.'

			else:
				message = 'Please Approve The Course'

		else:
			message = 'Have No Zoom Credentials'
		connection.commit()
		cursor.close()
		

		
		return ({"attributes": {"status_desc": "Meeting Details",
								"status": "success",
								"message":message,
								"platform":'zoom'
									},
				"responseList":res}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/getUpcomingLiveclassDtls/<string:exam>")
class getUpcomingLiveclassDtls(Resource):
	def get(self,exam):
		connection = connect_recess()
		cursor = connection.cursor()

		
		tdate = date.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		upcomingclasses = []
		
		cursor.execute("""SELECT lm.`liveclass_id`,lm.`course_id`,`exam`
		 	FROM `liveclass_mapping` lm inner join course_master cm 
		 	on lm.`course_id` = cm.`course_id` 
            where date(`start_date`)>=%s and `exam`=%s""",(tdate,exam))
		upliveclass = cursor.fetchall()

		for i in range(len(upliveclass)):
			cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
			 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
			 	(upliveclass[i]['liveclass_id']))
			chkduration = cursor.fetchone()
			if chkduration:
				sttime = chkduration['start_date'].isoformat()
				st = sttime.replace('T', ' ')
				strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
				entime = chkduration['duration']
				
				hoursadded =  timedelta(hours=entime)
				futuredtime = strtime + hoursadded
				
				if futuredtime >= todays:
					cursor.execute("""SELECT lm.`liveclass_id`,lm.`course_id`,`exam`,
						`course_title`,`content_name`,lm.`teacher_id`,
						`zoom_meeting_id`,`zoom_uuid`,`zoom_join_url`,
						`start_date`,`duration`,`subject`,`description`,`topic` FROM `liveclass_mapping` lm 
			            inner join course_master cm on lm.`course_id` = cm.`course_id` 
			            where lm.`liveclass_id`=%s""",(upliveclass[i]['liveclass_id']))
					upcomingliveclassdtls = cursor.fetchone()

					upcomingliveclassdtls['start_date'] = upcomingliveclassdtls['start_date'].isoformat()
					
					cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
						as 'name',imageurl FROM `user_credential`where user_id=%s""",
						(upcomingliveclassdtls['teacher_id']))
					teacherdtls = cursor.fetchone()
					if teacherdtls:
						teachername = teacherdtls['name']
						upcomingliveclassdtls['teachername'] = teachername
						
					else:
						teachername = ''
						upcomingliveclassdtls['teachername'] = teachername
					
					cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
						liveclass_student_mapping where `liveclass_id`=%s""",
			            (upcomingliveclassdtls['liveclass_id']))
					signupliveclass = cursor.fetchone()
					if signupliveclass:
						signupclass = signupliveclass['total']
						upcomingliveclassdtls['Signup'] = signupclass
					else:
						signupclass = 0
						upcomingliveclassdtls['Signup'] = signupclass
					
					upcomingclasses.append(upcomingliveclassdtls)

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Upcoming Live Class Details",
                                "status": "success"
                                },
                 "responseList": upcomingclasses}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/getCompletedLiveclassDtlsByStudentId/<int:student_id>")
class getCompletedLiveclassDtlsByStudentId(Resource):
	def get(self,student_id):
		connection = connect_recess()
		cursor = connection.cursor()

		tdate = datetime.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		
		cursor.execute("""SELECT lm.`liveclass_id`,lm.`course_id`,`exam`,`course_title`,
			`content_name`,`content_description`,`zoom_meeting_id`,`zoom_uuid`,
			`zoom_join_url`,lm.`teacher_id`,`start_date`,`duration`,`subject`,
			`description`,`topic` FROM liveclass_mapping lm INNER JOIN
		    course_master cm ON lm.`course_id` = cm.`course_id` INNER JOIN
		    liveclass_student_mapping lsm ON lm.`liveclass_id` = lsm.`liveclass_id`
			WHERE `start_date`< %s AND `student_id` = %s""",(todays,student_id))
		completedliveclassdtls = cursor.fetchall()

		for i in range(len(completedliveclassdtls)):
			completedliveclassdtls[i]['start_date'] = completedliveclassdtls[i]['start_date'].isoformat()
			completedliveclassdtls[i]['duration'] = 0
			
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
				as 'name',imageurl FROM `user_credential`where user_id=%s""",
				(completedliveclassdtls[i]['teacher_id']))
			teacherdtls = cursor.fetchone()
			if teacherdtls:
				teachername = teacherdtls['name']
				completedliveclassdtls[i]['teachername'] = teachername
				
			else:
				teachername = ''
				completedliveclassdtls[i]['teachername'] = teachername
				
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Completed Live Class Details",
                                "status": "success"
                                },
                 "responseList": completedliveclassdtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/CourseListAndLiveClassDtlsByExam/<string:exam>")
class CourseListAndLiveClassDtlsByExam(Resource):
	def get(self,exam):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()

		cursor.execute("""SELECT `course_id`, `course_title`, 
			`course_starting`, `course_ending`, `flag`, `admin_id`, 
			`content_name`, `content_description`, `course_image`, 
			`course_filetype`, `teacher_id`, `exam`,  `last_update_id`, 
			`last_update_ts` FROM `course_master` WHERE `flag`='Approved'""")
		ApprovedCoursedtls = cursor.fetchall()
		
		if ApprovedCoursedtls:

			for i in range(len(ApprovedCoursedtls)):
				ApprovedCoursedtls[i]['course_starting'] = ApprovedCoursedtls[i]['course_starting'].isoformat()
				ApprovedCoursedtls[i]['course_ending'] = ApprovedCoursedtls[i]['course_ending'].isoformat()
				ApprovedCoursedtls[i]['last_update_ts'] = ApprovedCoursedtls[i]['last_update_ts'].isoformat()

				cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
					as 'name',imageurl FROM `user_credential`where user_id=
					%s""",(ApprovedCoursedtls[i]['teacher_id']))
				teacherdtls = cursor.fetchone()
				if teacherdtls:
					teachername = teacherdtls['name']
					imageurl = teacherdtls['imageurl']
					ApprovedCoursedtls[i]['teachername'] = teachername
					ApprovedCoursedtls[i]['imageurl'] = imageurl
				else:
					teachername = ''
					imageurl = ''
					ApprovedCoursedtls[i]['teachername'] = teachername
					ApprovedCoursedtls[i]['imageurl'] = imageurl
					
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Course List",
                                "status": "success"
                                },
                 "responseList": ApprovedCoursedtls}), status.HTTP_200_OK

#--------------------------------------------------------------------#
@name_space.route("/LiveClassDtlsByCourseId/<string:course_id>")
class LiveClassDtlsByCourseId(Resource):
	def get(self,course_id):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()
		
		cursor.execute("""SELECT `liveclass_id`,lm.`course_id`,
			`exam`,`zoom_meeting_id`,`zoom_uuid`, `zoom_join_url`,
			lm.`teacher_id`, `start_date`,
			`duration`,`subject`,`description`,`topic` FROM 
			liveclass_mapping lm inner join course_master cm on 
			lm.`course_id` = cm.`course_id` where lm.`course_id`=%s""",
			(course_id))
		upcomingliveclassdtls = cursor.fetchall()

		for i in range(len(upcomingliveclassdtls)):
			upcomingliveclassdtls[i]['start_date'] = upcomingliveclassdtls[i]['start_date'].isoformat()
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
				as 'name',imageurl FROM `user_credential`where user_id=%s""",
				(upcomingliveclassdtls[i]['teacher_id']))
			teacherdtls = cursor.fetchone()
			if teacherdtls:
				teachername = teacherdtls['name']
				upcomingliveclassdtls[i]['teachername'] = teachername
				
			else:
				teachername = ''
				upcomingliveclassdtls[i]['teachername'] = teachername

			cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
				liveclass_student_mapping where `liveclass_id`=%s""",
	            (upcomingliveclassdtls[i]['liveclass_id']))
			signupliveclass = cursor.fetchone()
			if signupliveclass:
				signupclass = signupliveclass['total']
				upcomingliveclassdtls[i]['Signup'] = signupclass
			else:
				signupclass = 0
				upcomingliveclassdtls[i]['Signup'] = signupclass
			
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
                 "responseList": upcomingliveclassdtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/LiveClassHistoryByTeacherIdStartEndDate/<int:teacher_id>/<string:starting_date>/<string:ending_date>")
class LiveClassHistoryByTeacherIdStartEndDate(Resource):
	def get(self,teacher_id,starting_date,ending_date):
		connection = connect_recess()
		cursor = connection.cursor()
		
		tdate = date.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		details = []
		detail = []
		detal = []

		cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
			liveclass_mapping where `teacher_id`=%s and Date(`last_update_ts`) 
			between %s and %s""",(teacher_id,starting_date,ending_date))
		totalliveclass = cursor.fetchone()
		if totalliveclass:
			totalClass = totalliveclass['total'] 
		else:
			totalClass = 0

		cursor.execute("""SELECT `liveclass_id` FROM liveclass_mapping 
			where `teacher_id`=%s and date(`start_date`)=%s""",
			(teacher_id,tdate))
		liveclass = cursor.fetchall()
		if liveclass != ():
			for i in range(len(liveclass)):
				cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
				 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
				 	(liveclass[i]['liveclass_id']))
				chkduration = cursor.fetchone()
				if chkduration:
					sttime = chkduration['start_date'].isoformat()
					st = sttime.replace('T', ' ')
					strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
					entime = chkduration['duration']
					
					hoursadded =  timedelta(hours=entime)
					futuredtime = strtime + hoursadded
					
					if futuredtime >= todays:
						details.append(liveclass[i]['liveclass_id'])
			activeClass = len(details)
					
		else:
			activeClass= 0

		cursor.execute("""SELECT student_id FROM liveclass_mapping lm 
			inner join student_liveclass_tracking slt on 
			lm.`liveclass_id` = slt.`liveclass_id`
            where `teacher_id`=%s and Date(`start_date`) 
			between %s and %s""",(teacher_id,starting_date,ending_date))
		attendliveclasses = cursor.fetchall()
		
		if attendliveclasses != ():
			for i in range(len(attendliveclasses)):
				cursor.execute("""SELECT user_role FROM user_credential 
					where `user_id`=%s""",(attendliveclasses[i]['student_id']))
				userrole = cursor.fetchone()
				if userrole['user_role'] == 'S1':
					detail.append(attendliveclasses[i]['student_id'])
			attendClass = len(detail)
			
		else:
			attendClass = 0

		cursor.execute("""SELECT lm.`liveclass_id` FROM liveclass_mapping lm
			inner join liveclass_student_mapping lsm on 
			lm.`liveclass_id` = lsm.`liveclass_id`
			where `teacher_id`=%s and date(`start_date`)=%s""",
			(teacher_id,tdate))
		liveclass = cursor.fetchall()
		if liveclass != ():
			for i in range(len(liveclass)):
				cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
				 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
				 	(liveclass[i]['liveclass_id']))
				chkduration = cursor.fetchone()
				if chkduration:
					sttime = chkduration['start_date'].isoformat()
					st = sttime.replace('T', ' ')
					strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
					entime = chkduration['duration']
					
					hoursadded =  timedelta(hours=entime)
					futuredtime = strtime + hoursadded
					
					if futuredtime >= todays:
						cursor.execute("""SELECT count(student_id)as total FROM 
							liveclass_student_mapping where `liveclass_id`=%s""",
				            (liveclass[i]['liveclass_id']))
						signupactiveclass = cursor.fetchone()
						detal.append(signupactiveclass['total'])
						signupClass = sum(detal)
						
					else:
						signupClass = 0
		else:
			signupClass = 0

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
                 "responseList":{
                 	"totalLiveClasses":totalClass,
                 	"ActiveLiveClasses":activeClass,
                 	"AttendLiveClasses":attendClass,
                 	"SignUpActiveLiveClasses":signupClass
                 	},
                 }), status.HTTP_200_OK

#-----------------------------------------------------------------#
@name_space.route("/RegisterToLiveClass")	
class RegisterToLiveClass(Resource):
	@api.expect(register_liveclass)
	def post(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		liveDtls = details['liveclassDtls']

		for lcid, dtls in enumerate(liveDtls):
			cursor.execute("""SELECT `mapping_id` FROM 
				`liveclass_student_mapping` where `liveclass_id`=%s and
				`student_id`=%s""",(liveDtls[lcid]['liveclass_id'],details['student_id']))
			existsLiveClassDtls = cursor.fetchone()
			
			if existsLiveClassDtls:
				msg = 'Already Registered!!!'
			
			else:
				cursor.execute("""SELECT `teacher_id` FROM `liveclass_mapping` 
					where `liveclass_id`=%s""",(liveDtls[lcid]['liveclass_id']))
				classteacherid = cursor.fetchone()

				insert_query = ("""INSERT INTO `liveclass_student_mapping`(`liveclass_id`,
					`student_id`) VALUES(%s,%s)""")
				insert_data = (liveDtls[lcid]['liveclass_id'],details['student_id'])
				insertdata = cursor.execute(insert_query,insert_data)

				cursor.execute("""SELECT `previous_balance`,`added_balance`,
					`updated_balance` FROM `student_wallet_transaction` WHERE 
					`student_id` = %s ORDER BY `transaction_id` DESC""",(details['student_id']))
				wallettrnsDtls = cursor.fetchone()

				previous_amount = wallettrnsDtls.get('updated_balance')

				if previous_amount == 'unlimited' or wallettrnsDtls['added_balance'] == 'unlimited':
					updated_amount = 'unlimited'
					deducted_amount = '0'

				else:
					updated_amount = int(wallettrnsDtls['updated_balance']) - 1
					deducted_amount = '1'


				transQuery = ("""INSERT INTO `student_wallet_transaction`(`student_id`,
					`previous_balance`,`deducted_balance`,`updated_balance`) VALUES (%s,
					%s,%s,%s)""")
				
				transData = cursor.execute(transQuery,(details['student_id'],previous_amount,
					deducted_amount,updated_amount))

				updateWallet = ("""UPDATE `student_wallet` SET 
					`update_amount`=%s where `student_id` = %s""")
				cursor.execute(updateWallet,(updated_amount,details['student_id']))

				msg = 'Registered Successfully!!!'

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
             	"responseList": msg}), status.HTTP_200_OK
	 									
#---------------------------------------------------------------------------#
@name_space.route("/LiveClassWalletBalanceByStudentID/<int:student_id>")
class LiveClassWalletBalanceByStudentID(Resource):
	def get(self,student_id):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()

		cursor.execute("""SELECT wallet_id,update_amount as wallet_amount FROM 
			student_wallet where `student_id`=%s""",(student_id))
		walletDtls = cursor.fetchone()
		if walletDtls:
			walletBalance = walletDtls
		else:
			walletBalance =[]
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Wallet Details",
                                "status": "success"
                                },
                 "responseList":walletBalance}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/getUpcomingLiveclassDtlsByStudentId/<int:student_id>")
class getUpcomingLiveclassDtlsByStudentId(Resource):
	def get(self,student_id):
		connection = connect_recess()
		cursor = connection.cursor()

		tdate = date.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		
		upcomingclasses = []

		cursor.execute("""SELECT `liveclass_id` FROM `liveclass_mapping` lm 
            where `liveclass_id`in(SELECT liveclass_id FROM 
            `liveclass_student_mapping` where student_id=%s) and 
            date(`start_date`)>=%s""",(student_id,tdate))
		upliveclass = cursor.fetchall()

		for i in range(len(upliveclass)):
			
			cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
			 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
			 	(upliveclass[i]['liveclass_id']))
			chkduration = cursor.fetchone()
			if chkduration:
				sttime = chkduration['start_date'].isoformat()
				st = sttime.replace('T', ' ')
				strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
				entime = chkduration['duration']
				
				hoursadded =  timedelta(hours=entime)
				futuredtime = strtime + hoursadded
				
				if futuredtime >= todays:
					
					cursor.execute("""SELECT lm.`liveclass_id`,lm.`course_id`,`exam`,
						`course_title`,`content_name`,lm.`teacher_id`,
						`zoom_meeting_id`,`zoom_uuid`,`zoom_join_url`,
						`start_date`,`duration`,`subject`,`description`,`topic` FROM `liveclass_mapping` lm 
			            inner join course_master cm on lm.`course_id` = cm.`course_id` 
			            where lm.`liveclass_id`=%s""",(upliveclass[i]['liveclass_id']))
					upcomingliveclassdtls = cursor.fetchone()

					upcomingliveclassdtls['start_date'] = upcomingliveclassdtls['start_date'].isoformat()
					
					cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
						as 'name',imageurl FROM `user_credential`where user_id=%s""",
						(upcomingliveclassdtls['teacher_id']))
					teacherdtls = cursor.fetchone()
					if teacherdtls:
						teachername = teacherdtls['name']
						upcomingliveclassdtls['teachername'] = teachername
						
					else:
						teachername = ''
						upcomingliveclassdtls['teachername'] = teachername
				
					upcomingclasses.append(upcomingliveclassdtls)

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Upcoming Live Class Details",
                                "status": "success"
                                },
                 "responseList": upcomingclasses}), status.HTTP_200_OK

#-----------------------------------------------------------------------------#
@name_space.route("/addImageurl")	
class addImageurl(Resource):
	@api.expect(addImageurl)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		imageurl = details.get('imageurl')
		user_id = details.get('user_id')

		update_image = ("""UPDATE `user_credential` SET `imageurl`= %s
        	WHERE `user_id`=%s""")
		cursor.execute(update_image,(imageurl,user_id))

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Added Image Url",
                            "status": "success"
                            },
                "responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------------#
@name_space.route("/AvailableCourses")
class AvailableCourses(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `course_id`, `course_title`, 
			`course_starting`, `course_ending`, `flag`, `admin_id`, 
			`content_name`, `content_description`, `course_image`, 
			`course_filetype`, `teacher_id`, `exam`,  `last_update_id`, 
			`last_update_ts` FROM `course_master` ORDER BY RAND()""")
		Coursedtls = cursor.fetchall()
		
		if Coursedtls:
			for i in range(len(Coursedtls)):
				Coursedtls[i]['course_starting'] = Coursedtls[i]['course_starting'].isoformat()
				Coursedtls[i]['course_ending'] = Coursedtls[i]['course_ending'].isoformat()
				Coursedtls[i]['last_update_ts'] = Coursedtls[i]['last_update_ts'].isoformat()
				
				cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
					as 'name',imageurl FROM `user_credential`where 
					user_id=%s""",(Coursedtls[i]['teacher_id']))
				teacherdtls = cursor.fetchone()
				if teacherdtls:
					teachername = teacherdtls['name']
					imageurl = teacherdtls['imageurl']
					Coursedtls[i]['teachername'] = teachername
					Coursedtls[i]['imageurl'] = imageurl
				else:
					teachername = ''
					imageurl = ''
					Coursedtls[i]['teachername'] = teachername
					Coursedtls[i]['imageurl'] = imageurl
		else:
			[]

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Course List",
                                "status": "success"
                                },
                 "responseList": Coursedtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/getContentListByTeacherId/<int:teacher_id>")
class getContentListByTeacherId(Resource):
	def get(self,teacher_id):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT content_id,content_name,co_contentname,
			content_filepath,content_filename,content_filetype,exam,
			teacher_id FROM content_library where teacher_id=%s""",(teacher_id))
		Contentdtls = cursor.fetchall()

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Content Details",
                                "status": "success"
                                },
                 "responseList": Contentdtls}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/getTeacherRegistrationStatus")
class getTeacherRegistrationStatus(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
			`user_role`,`flag`,`email_id`,`phone_no`,`password`,`exam`,`experience`,
			`qualification`,`videolink`,`imageurl`,`last_update_ts` FROM 
			`user_credential` where `user_role`='T1'""")
		userCredentialDtls = cursor.fetchall()

		if userCredentialDtls:
			for i in range(len(userCredentialDtls)):
				userCredentialDtls[i]['last_update_ts'] = userCredentialDtls[i]['last_update_ts'].isoformat()
		
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Teacher Registration Status Details",
                                "status": "success"
                                },
                 "responseList": userCredentialDtls}), status.HTTP_200_OK

#-----------------------------------------------------------------------------#
@name_space.route("/UpdateRegistratonStatus")	
class UpdateRegistratonStatus(Resource):
	@api.expect(updateteacher_Status)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		teacher_id = details.get('teacher_id')
		admin_id = details.get('admin_id')
		flag = details.get('flag')
		
		if flag == "Decline":
			delete_query = ("""DELETE FROM `user_credential` WHERE 
				`user_id`=%s""")
			cursor.execute(delete_query,(teacher_id))

			msg = "User Account Removed"
		else:
			update_status = ("""UPDATE `user_credential` SET `flag`= %s,
				`admin_id`=%s WHERE `user_id`=%s""")
			cursor.execute(update_status,(flag,admin_id,teacher_id))

			msg = "User Account Updated"
		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Update Registration Status Details",
                            "status": "success",
                            "msg": msg
                            },
                "responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------------#
@name_space.route("/AdminSignIn")
class AdminSignIn(Resource):
	@api.expect(adminsignin)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()
		
		phone_no = details.get('phone_no')
		password = details.get('password')
		
		
		cursor.execute("""SELECT admin_id, name, password, phone_no 
			FROM `admin_dtls` WHERE `phone_no`=%s and `password`=%s""",
			(phone_no,password))
		userCredentialDtls = cursor.fetchone()
		if userCredentialDtls:
			return ({"attributes": {
									"status_desc": "Admin Signin Details",
									"status": "success"
									},
			"responseList": userCredentialDtls}), status.HTTP_200_OK
	
		else:
			return ({"attributes": {
									"status_desc": "User Signin Details",
									"status": "success"
								},
				"responseList": "Invalid Password Or Phone Number"}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/UpdateCourseStatus")	
class ApproveCourse(Resource):
	@api.expect(updatecourse_Status)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		course_id = details.get('course_id')
		admin_id = details.get('admin_id')
		flag = details.get('flag')

		update_status = ("""UPDATE `course_master` SET `flag`= %s,
			`admin_id`=%s WHERE `course_id`=%s""")
		cursor.execute(update_status,(flag,admin_id,course_id))

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Update Course Status Details",
                            "status": "success"
                            },
                "responseList":details}), status.HTTP_200_OK

#---------------------------------------------------------------------#
@name_space.route("/getUpcomingNotRegisteredLiveclassDtlsByCourseStudentId/<int:course_id>/<int:student_id>")
class getUpcomingNotRegisteredLiveclassDtlsByCourseStudentId(Resource):
	def get(self,course_id,student_id):
		connection = connect_recess()
		cursor = connection.cursor()

		tdate = datetime.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		
		cursor.execute("""SELECT lm.`liveclass_id`,lm.`course_id`,`exam`,
			`course_title`,`content_name`,lm.`teacher_id`,
			`zoom_meeting_id`,`zoom_uuid`,`zoom_join_url`,
			`start_date`,`duration`,`subject`,`description`,`topic` FROM 
			`liveclass_mapping` lm 
			inner join course_master cm on lm.`course_id` = cm.`course_id` 
            where `liveclass_id` not in(SELECT liveclass_id FROM 
            `liveclass_student_mapping` where student_id=%s) and lm.`course_id`=%s 
            and `start_date`>=%s""",(student_id,course_id,todays))
		upcomingclasses = cursor.fetchall()

		for i in range(len(upcomingclasses)):
			
			upcomingclasses[i]['start_date'] = upcomingclasses[i]['start_date'].isoformat()
			
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)
				as 'name',imageurl FROM `user_credential`where user_id=%s""",
				(upcomingclasses[i]['teacher_id']))
			teacherdtls = cursor.fetchone()
			if teacherdtls:
				teachername = teacherdtls['name']
				upcomingclasses[i]['teachername'] = teachername
				
			else:
				teachername = ''
				upcomingclasses[i]['teachername'] = teachername
			
			

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Upcoming Live Class Details",
                                "status": "success"
                                },
                 "responseList": upcomingclasses}), status.HTTP_200_OK

#-------------------------------------------------------------------------#
@name_space.route("/StudentLiveClassTracking")	
class StudentLiveClassTracking(Resource):
	@api.expect(liveclasstracking)
	def post(self):

		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()
		details = request.get_json()

		Student_ID = details.get('Student_ID')
		liveclass_id = details.get('liveclass_id')
		Duration = details.get('Duration')
		Status = details.get('Status')

		cursor.execute("""SELECT date(start_date)as stdate FROM `liveclass_mapping` 
			where liveclass_id=%s""",(liveclass_id))
		Scheduleddate = cursor.fetchone()
		
		if Scheduleddate['stdate'] == today:
			
			cursor.execute("""SELECT Student_ID,liveclass_id FROM 
				`student_liveclass_tracking` where Student_ID=%s and 
				liveclass_id=%s""",(Student_ID,liveclass_id))
			trackdtls = cursor.fetchone()
			if trackdtls == None:
				cursor.execute("""SELECT `user_id`,user_role FROM `user_credential` 
					WHERE `user_id`=%s""",(Student_ID))
				userCredentialDtls = cursor.fetchone()

				if userCredentialDtls['user_role'] == 'T1':

					trackdtls_query = ("""INSERT INTO `student_liveclass_tracking`(Student_ID,
						liveclass_id,Duration,Status)VALUES (%s,%s,%s,%s)""")
					
					trackdata = cursor.execute(trackdtls_query,
						(Student_ID,liveclass_id,Duration,Status))
					if trackdata:

						URL = BASE_URL + "earning_section/Recess/TeacherEarning"

						headers = {'Content-type':'application/json', 'Accept':'application/json'}

						payload = {
									"teacher_id":Student_ID,
									"liveclass_id":liveclass_id
								}
							
						earnResponse = requests.post(URL,data=json.dumps(payload), headers=headers).json()
						
						msg = "Tracking Details Added"


					else:
						msg = "Not Added"

				else:
					trackdtls_query = ("""INSERT INTO `student_liveclass_tracking`(Student_ID,
						liveclass_id,Duration,Status)VALUES (%s,%s,%s,%s)""")
					
					trackdata = cursor.execute(trackdtls_query,
						(Student_ID,liveclass_id,Duration,Status))
					if trackdata:
						msg = "Tracking Details Added"

					else:
						msg = "Not Added"
			else:
				msg = "Already Added"
		else:
			msg = "Mismatch Scheduled Date"

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Live Class Tracking Details",
                            "status": "success"
                            },
                "responseList": msg}), status.HTTP_200_OK

#---------------------------------------------------------------------#
@name_space.route("/TeacherPerformanceByDate/<string:starting_date>/<string:ending_date>")
class TeacherPerformanceByDate(Resource):
	def get(self,starting_date,ending_date):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()
		perList = []
		cursor.execute("""SELECT user_id,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
		 imageurl FROM user_credential where `flag`="Approved" and user_role='T1'""")
		teacherList = cursor.fetchall()

		if teacherList:
			for tid, techr in enumerate(teacherList):
				cursor.execute("""SELECT count(`course_id`)as total FROM 
					course_master where `teacher_id`=%s and Date(`course_starting`) 
					between %s and %s""",(techr.get('user_id'),starting_date,ending_date))
				totalcourses = cursor.fetchone()
				if totalcourses:
					totalCourses = totalcourses['total'] 
					teacherList[tid]['totalCourses'] = totalCourses
				else:
					totalCourses = 0
					teacherList[tid]['totalCourses'] = totalCourses

				cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
					liveclass_mapping where `teacher_id`=%s and Date(`last_update_ts`) 
					between %s and %s""",(techr.get('user_id'),starting_date,ending_date))
				totalliveclass = cursor.fetchone()
				if totalliveclass:
					totalClass = totalliveclass['total'] 
					teacherList[tid]['totalLiveClasses'] = totalClass
				else:
					totalClass = 0
					teacherList[tid]['totalLiveClasses'] = totalClass

				cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
					liveclass_mapping where `teacher_id`=%s and Date(`start_date`) 
					= %s""",(techr.get('user_id'),today))
				activeliveclass = cursor.fetchone()
				if activeliveclass:
					activeClass = activeliveclass['total']
					teacherList[tid]['ActiveLiveClasses'] = activeClass
				else:
					activeClass = 0
					teacherList[tid]['activeClass'] = activeClass

				cursor.execute("""SELECT count(lm.`liveclass_id`)as total FROM 
					liveclass_mapping lm inner join student_liveclass_tracking slt on 
					lm.`liveclass_id` = slt.`liveclass_id`
		            where `teacher_id`=%s and Date(`start_date`) 
					between %s and %s""",(techr.get('user_id'),starting_date,ending_date))
				attendliveclass = cursor.fetchone()
				if attendliveclass:
					attendClass = attendliveclass['total'] 
					teacherList[tid]['AttendLiveClasses'] = attendClass
				else:
					attendClass = 0
					teacherList[tid]['AttendLiveClasses'] = attendClass

				cursor.execute("""SELECT count(lm.`liveclass_id`)as total FROM 
					liveclass_mapping lm inner join liveclass_student_mapping lsm on 
					lm.`liveclass_id` = lsm.`liveclass_id`
		            where `teacher_id`=%s and Date(`start_date`)=%s""",
		            (techr.get('user_id'),today))
				signupactiveclass = cursor.fetchone()
				if signupactiveclass:
					signupClass = signupactiveclass['total'] 
					teacherList[tid]['SignUpActiveLiveClasses'] = signupClass
				else:
					signupClass = 0
					teacherList[tid]['SignUpActiveLiveClasses'] = signupClass
					
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
                 "responseList":teacherList}), status.HTTP_200_OK

#--------------------------------------------------------------------#
@name_space.route("/UpdateProfile")	
class UpdateProfile(Resource):
	@api.expect(update_profile)
	def put(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		user_id = details.get('user_id')
		Name = details.get('name')
		User_role = details.get('user_role')
		Email_id = details.get('email_id')
		Ph_no = details.get('phone_no')
		Password = details.get('password')
		Exam = details.get('exam')
		Imageurl =details.get('imageurl')
		Experience = details.get('experience')
		Qualification = details.get('qualification')
		Videolink = details.get('videolink')
		
		if Name:
			if len(Name.split(" ")) < 2:
				First_name = Name
				Middle_name = ''
				Last_name = ''
				
			elif len(Name.split(" ")) == 2:
				parsed_name = Name.split(" ", 1)
				First_name = parsed_name[0]
				Middle_name = ''
				Last_name = parsed_name[1]
				
			else:
				parsed_name = Name.split(" ", 2)
				First_name = parsed_name[0]
				Middle_name = parsed_name[1]
				Last_name = parsed_name[2]

		else:
			cursor.execute("""SELECT `user_id`,`first_name`,`middle_name`,
				`last_name`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,
				`experience`,`qualification`,`videolink`,`imageurl` FROM 
				`user_credential` WHERE `user_id`=%s""",(user_id))
			usercredentialDtls = cursor.fetchone()

			if usercredentialDtls:
			
				First_name = usercredentialDtls.get('first_name')
	               
				Middle_name = usercredentialDtls.get('middle_name')
				    
				Last_name = usercredentialDtls.get('last_name')
			
		cursor.execute("""SELECT `user_id`,`first_name`,`middle_name`,
			`last_name`,`user_role`,`email_id`,`phone_no`,`password`,`exam`,
			`experience`,`qualification`,`videolink`,`imageurl` FROM 
			`user_credential` WHERE `user_id`=%s""",(user_id))
		userCredentialDtls = cursor.fetchone()

		if userCredentialDtls:
		
			if not First_name:
				First_name = userCredentialDtls.get('first_name')
               
			if not Middle_name:
			    Middle_name = userCredentialDtls.get('middle_name')
			    
			if not Last_name:
			    Last_name = userCredentialDtls.get('last_name')
			    
			if not Email_id:
			    Email_id = userCredentialDtls.get('email_id')

			if not Ph_no:
			    Ph_no = userCredentialDtls.get('phone_no')

			if not Password:
			    Password = userCredentialDtls.get('password')
			    
			if not Exam:
			    Exam = userCredentialDtls.get('exam')
			    
			if not Experience:
			    Experience = userCredentialDtls.get('experience')

			if not Qualification:
			    Qualification = userCredentialDtls.get('qualification')
			    
			if not Videolink:
			    Videolink = userCredentialDtls.get('videolink')
			    
			if not Imageurl:
			    Imageurl = userCredentialDtls.get('imageurl')
               
		update_profile = ("""UPDATE `user_credential` SET `first_name`=%s,
			`middle_name`=%s,`last_name`=%s,`email_id`=%s,`phone_no`=%s,
			`password`=%s,`exam`=%s,`experience`=%s,`qualification`=%s,
			`videolink`=%s,`imageurl`=%s WHERE `user_id`=%s""")
		cursor.execute(update_profile,(First_name,Middle_name,Last_name,
			Email_id,Ph_no,Password,Exam,Experience,Qualification,
			Videolink,Imageurl,user_id))

		msg = "Updated"
		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "Update Profile Details",
                            "status": "success",
                            "msg": msg
                            },
                "responseList":details}), status.HTTP_200_OK

#-------------------------------------------------------------------#
@name_space.route("/AddUserZoomCredential")	
class AddUserZoomCredential(Resource):
	@api.expect(zoomdtls)
	def post(self):

		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		user_phoneno = details.get('user_phoneno')
		email_id = details.get('email_id')
		zoom_password = details.get('zoom_password')
		zoom_api_key = details.get('zoom_api_key')

		cursor.execute("""SELECT `user_id` FROM `user_credential` 
			WHERE `phone_no`=%s and `user_role`='T1'""",(user_phoneno))
		userCredentialDtls = cursor.fetchone()

		if userCredentialDtls:
			userid = userCredentialDtls['user_id']

			cursor.execute("""SELECT `user_id` FROM `zoom_user_details` 
				WHERE `user_id`=%s""",(userid))
			userzoomDtls = cursor.fetchone()

			if userzoomDtls:
				msg = 'Already Exists Zoom Details'

			else:
				zoomdtls_query = ("""INSERT INTO `zoom_user_details`(`user_id`, 
					`platform`,`zoom_password`,`user_mailid`,`zoom_api_key`,
					`token_expiration_date`,`last_update_id`)VALUES (%s,%s,%s,%s,
					%s,%s,%s)""")
				
				cursor.execute(zoomdtls_query,(userid,'zoom',zoom_password,
					email_id,zoom_api_key,'',userid))

				msg = 'Zoom user details Added Successfully'
		else:
			msg = 'User Not Exists'

		connection.commit()
		cursor.close()
		
		return ({"attributes": {"status_desc": "User Zoom Details",
                            "status": "success"
                            },
                "responseList":msg}), status.HTTP_200_OK

#---------------------------------------------------------------#
@name_space.route("/TeacherPerformance")
class TeacherPerformance(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()
		today = date.today()
		teachList = []
		cursor.execute("""SELECT user_id FROM user_credential where 
			`flag`="Approved" and user_role='T1'""")
		teacherList = cursor.fetchall()

		if teacherList:
			for tid, techr in enumerate(teacherList):
				teachList.append(techr.get('user_id'))
			teachList = tuple(teachList)
			
			cursor.execute("""SELECT count(`course_id`)as total FROM 
				course_master where `flag`='Approved' and `teacher_id` in %s and Date(`last_update_ts`) 
				between %s and %s""",(teachList,"2021-01-01",today))
			totalcourses = cursor.fetchone()
			if totalcourses:
				totalCourses = totalcourses['total'] 
				teacherList[tid]['totalCourses'] = totalCourses
			else:
				totalCourses = 0
				teacherList[tid]['totalCourses'] = totalCourses

			cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
				liveclass_mapping where `teacher_id` in %s and Date(`start_date`) 
				between %s and %s""",(teachList,"2021-01-01",today))
			totalliveclass = cursor.fetchone()
			if totalliveclass:
				totalClass = totalliveclass['total'] 
				teacherList[tid]['totalLiveClasses'] = totalClass
			else:
				totalClass = 0
				teacherList[tid]['totalLiveClasses'] = totalClass

			cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
				liveclass_mapping where `teacher_id` in %s and Date(`start_date`) 
				= %s""",(teachList,today))
			activeliveclass = cursor.fetchone()
			if activeliveclass:
				activeClass = activeliveclass['total']
				teacherList[tid]['ActiveLiveClasses'] = activeClass
			else:
				activeClass = 0
				teacherList[tid]['activeClass'] = activeClass

			cursor.execute("""SELECT count(lm.`liveclass_id`)as total FROM 
				liveclass_mapping lm inner join student_liveclass_tracking slt on 
				lm.`liveclass_id` = slt.`liveclass_id`
	            where `teacher_id` in %s and Date(`start_date`) 
				between %s and %s""",(teachList,"2021-01-01",today))
			attendliveclass = cursor.fetchone()
			if attendliveclass:
				attendClass = attendliveclass['total'] 
				teacherList[tid]['AttendLiveClasses'] = attendClass
			else:
				attendClass = 0
				teacherList[tid]['AttendLiveClasses'] = attendClass

			cursor.execute("""SELECT count(lm.`liveclass_id`)as total FROM 
				liveclass_mapping lm inner join liveclass_student_mapping lsm on 
				lm.`liveclass_id` = lsm.`liveclass_id`
	            where `teacher_id` in %s and Date(`start_date`)=%s""",
	            (teachList,today))
			signupactiveclass = cursor.fetchone()
			if signupactiveclass:
				signupClass = signupactiveclass['total'] 
				teacherList[tid]['SignUpActiveLiveClasses'] = signupClass
			else:
				signupClass = 0
				teacherList[tid]['SignUpActiveLiveClasses'] = signupClass
				
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
                 "responseList":{
                 				"totalCourses":totalCourses,
			                 	"totalLiveClasses":totalClass,
			                 	"ActiveLiveClasses":activeClass,
			                 	"AttendLiveClasses":attendClass,
			                 	"SignUpActiveLiveClasses":signupClass,
			                 	"totalEarning":0,
			                 	"totalBonus":0
			                 	}
                 	}), status.HTTP_200_OK

#---------------------------------------------------------------#
@name_space.route("/OverAllTeacherPerformanceByDate/<string:starting_date>/<string:ending_date>")
class OverAllTeacherPerformanceByDate(Resource):
	def get(self,starting_date,ending_date):
		connection = connect_recess()
		cursor = connection.cursor()
		
		tdate = date.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		teachList = []
		details = []
		detail = []
		detal = []

		cursor.execute("""SELECT user_id FROM user_credential where 
			`flag`="Approved" and user_role='T1'""")
		teacherList = cursor.fetchall()

		if teacherList:
			for tid, techr in enumerate(teacherList):
				teachList.append(techr.get('user_id'))
			teachList = tuple(teachList)
			
			cursor.execute("""SELECT count(`course_id`)as total FROM 
				course_master where `flag`='Approved' and `teacher_id` in %s 
				and Date(`course_starting`) between %s and %s or 
				Date(`course_ending`) between %s and %s""",
				(teachList,starting_date,ending_date,starting_date,ending_date))
			totalcourses = cursor.fetchone()
			if totalcourses:
				totalCourses = totalcourses['total'] 
				
			else:
				totalCourses = 0

			cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
				liveclass_mapping where `teacher_id` in %s and Date(`last_update_ts`) 
				between %s and %s""",(teachList,starting_date,ending_date))
			totalliveclass = cursor.fetchone()
			if totalliveclass:
				totalClass = totalliveclass['total'] 
				
			else:
				totalClass = 0

			cursor.execute("""SELECT `liveclass_id` FROM liveclass_mapping 
				where `teacher_id` in %s and date(`start_date`)=%s""",
				(teachList,tdate))
			liveclass = cursor.fetchall()
			if liveclass != ():
				for i in range(len(liveclass)):
					cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
					 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
					 	(liveclass[i]['liveclass_id']))
					chkduration = cursor.fetchone()
					if chkduration:
						sttime = chkduration['start_date'].isoformat()
						st = sttime.replace('T', ' ')
						strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
						entime = chkduration['duration']
						
						hoursadded =  timedelta(hours=entime)
						futuredtime = strtime + hoursadded
						
						if futuredtime >= todays:
							details.append(liveclass[i]['liveclass_id'])
				activeClass = len(details)
				
			else:
				activeClass= 0

			cursor.execute("""SELECT student_id FROM liveclass_mapping lm 
				inner join student_liveclass_tracking slt on 
				lm.`liveclass_id` = slt.`liveclass_id`
	            where `teacher_id` in %s and Date(`start_date`) 
				between %s and %s""",(teachList,starting_date,ending_date))
			attendliveclasses = cursor.fetchall()
			if attendliveclasses != ():
				for i in range(len(attendliveclasses)):
					cursor.execute("""SELECT user_role FROM user_credential 
						where `user_id`=%s""",(attendliveclasses[i]['student_id']))
					userrole = cursor.fetchone()
					if userrole['user_role'] == 'S1':
						detail.append(attendliveclasses[i]['student_id'])
				attendClass = len(detail)
					
			else:
				attendClass = 0

			cursor.execute("""SELECT lm.`liveclass_id` FROM liveclass_mapping lm
				inner join liveclass_student_mapping lsm on 
				lm.`liveclass_id` = lsm.`liveclass_id`
				where `teacher_id` in %s and date(`start_date`)=%s""",
				(teachList,tdate))
			liveclass = cursor.fetchall()
			if liveclass != ():
				for i in range(len(liveclass)):
					cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
					 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
					 	(liveclass[i]['liveclass_id']))
					chkduration = cursor.fetchone()
					if chkduration:
						sttime = chkduration['start_date'].isoformat()
						st = sttime.replace('T', ' ')
						strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
						entime = chkduration['duration']
						
						hoursadded =  timedelta(hours=entime)
						futuredtime = strtime + hoursadded
						
						if futuredtime >= todays:
							cursor.execute("""SELECT count(student_id)as total FROM 
								liveclass_student_mapping where `liveclass_id`=%s""",
					            (liveclass[i]['liveclass_id']))
							signupactiveclass = cursor.fetchone()
							detal.append(signupactiveclass['total'])
							signupClass = sum(detal)
							
						else:
							signupClass = 0
			else:
				signupClass = 0

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "LiveClass Details",
                                "status": "success"
                                },
                 "responseList":{
                 				"totalCourses":totalCourses,
			                 	"totalLiveClasses":totalClass,
			                 	"ActiveLiveClasses":activeClass,
			                 	"AttendLiveClasses":attendClass,
			                 	"SignUpActiveLiveClasses":signupClass,
			                 	"totalEarning":0,
			                 	"totalBonus":0
			                 	}
                 	}), status.HTTP_200_OK

#---------------------------------------------------------------------------#
@name_space.route("/getApprovedTeacherDetails")
class getTeacherRegistrationStatus(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `user_id`,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
			`user_role`,`flag`,`email_id`,`phone_no`,`password`,`exam`,`experience`,
			`qualification`,`videolink`,`imageurl`,`last_update_ts` FROM 
			`user_credential` where `user_role`='T1' and `flag`='Approved'""")
		userCredentialDtls = cursor.fetchall()

		if userCredentialDtls:
			for i in range(len(userCredentialDtls)):
				userCredentialDtls[i]['last_update_ts'] = userCredentialDtls[i]['last_update_ts'].isoformat()
		
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Teacher Registration Status Details",
                                "status": "success"
                                },
                 "responseList": userCredentialDtls}), status.HTTP_200_OK

#-----------------------------------------------------------------------------#
@name_space.route("/AdminDetails")
class AdminDetails(Resource):
	def get(self):
		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT admin_id, name, password, phone_no 
			FROM `admin_dtls`""")
		adminCredentialDtls = cursor.fetchall()

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Admin Details",
                                "status": "success"
                                },
                 "responseList": adminCredentialDtls}), status.HTTP_200_OK

#-----------------------------------------------------------------#
@name_space.route("/TeacherPerformanceByTeacherId/<int:teacher_id>")
class TeacherPerformanceByTeacherId(Resource):
	def get(self,teacher_id):
		connection = connect_recess()
		cursor = connection.cursor()
		
		tdate = date.today()
		date_format='%Y-%m-%d %H:%M:%S'
		today = datetime.now(tz=pytz.utc)
		today = today.astimezone(timezone('Asia/Kolkata'))
		now = datetime.strftime(today, '%Y-%m-%d %H:%M:%S')
		todays = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
		details = []
		detal = []

		starting_date = '2021-05-01 00:00:00'
		
		cursor.execute("""SELECT count(`course_id`)as total FROM 
			course_master where flag='Approved' and `teacher_id`=%s 
			and Date(`course_ending`)<=%s""",(teacher_id,tdate))
		totalcourses = cursor.fetchone()
		if totalcourses:
			CompletedCourses = totalcourses['total'] 
			
		else:
			CompletedCourses = 0

		cursor.execute("""SELECT count(`course_id`)as total FROM 
			course_master where `teacher_id`=%s and Date(`course_ending`) 
			>=%s""",(teacher_id,tdate))
		totalupcourses = cursor.fetchone()
		if totalupcourses:
			UpcomingCourses = totalupcourses['total'] 
			
		else:
			UpcomingCourses = 0
			
		cursor.execute("""SELECT count(`liveclass_id`)as total FROM 
			liveclass_mapping where `teacher_id`=%s and `start_date`<%s""",
			(teacher_id,todays))
		comliveclass = cursor.fetchone()
		if comliveclass:
			CompletedClasses = comliveclass['total'] 
			
		else:
			CompletedClasses = 0
		
		cursor.execute("""SELECT `liveclass_id` FROM liveclass_mapping 
			where `teacher_id`=%s and date(`start_date`)>=%s""",
			(teacher_id,tdate))
		liveclass = cursor.fetchall()
		if liveclass != ():
			for i in range(len(liveclass)):
				cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
				 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
				 	(liveclass[i]['liveclass_id']))
				chkduration = cursor.fetchone()
				if chkduration:
					sttime = chkduration['start_date'].isoformat()
					st = sttime.replace('T', ' ')
					strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
					entime = chkduration['duration']
					
					hoursadded =  timedelta(hours=entime)
					futuredtime = strtime + hoursadded
					
					if futuredtime >= todays:
						details.append(liveclass[i]['liveclass_id'])
			UpcomingClasses = len(details)
					
		else:
			UpcomingClasses = 0
	

		cursor.execute("""SELECT count(lsm.`student_id`)as total FROM 
			liveclass_mapping lm inner join liveclass_student_mapping lsm
			on lm.`liveclass_id` = lsm.`liveclass_id` where `start_date`<%s""",
			(todays))
		comregliveclass = cursor.fetchone()
		if comregliveclass:
			CompletedClassesReg = comregliveclass['total']
			
		else:
			CompletedClassesReg = 0

		cursor.execute("""SELECT lm.`liveclass_id` FROM liveclass_mapping lm
			inner join liveclass_student_mapping lsm on 
			lm.`liveclass_id` = lsm.`liveclass_id` where 
			`teacher_id`=%s and date(`start_date`)>=%s""",(teacher_id,tdate))
		liveclass = cursor.fetchall()
		
		if liveclass != ():
			for i in range(len(liveclass)):
				cursor.execute("""SELECT `liveclass_id`,`duration`,`start_date`
				 	FROM `liveclass_mapping` where `liveclass_id`=%s""",
				 	(liveclass[i]['liveclass_id']))
				chkduration = cursor.fetchone()
				if chkduration:
					sttime = chkduration['start_date'].isoformat()
					st = sttime.replace('T', ' ')
					strtime = datetime.strptime(st, '%Y-%m-%d %H:%M:%S')
					entime = chkduration['duration']
					
					hoursadded =  timedelta(hours=entime)
					futuredtime = strtime + hoursadded
					
					if futuredtime >= todays:
						cursor.execute("""SELECT count(student_id)as total FROM 
							liveclass_student_mapping where `liveclass_id`=%s""",
				            (liveclass[i]['liveclass_id']))
						signupactiveclass = cursor.fetchone()
						detal.append(signupactiveclass['total'])
						UpcomingClassesReg = sum(detal)
						
					else:
						UpcomingClassesReg = 0
				else:
					UpcomingClassesReg = 0
		else:
			UpcomingClassesReg = 0

		cursor.execute("""SELECT previous_amount,updated_amount FROM teacher_payment_wallet
            where `teacher_id`=%s and admin_id !=0 and 
            Date(`last_update_ts`) between %s and %s order by transaction_id desc""",
            (teacher_id,starting_date,tdate))
		paymentliveclass = cursor.fetchone()

		if paymentliveclass:
			previous = paymentliveclass['previous_amount'] 
			updated = paymentliveclass['updated_amount'] 
			payment = previous - updated
		else:
			payment = 0
			
		cursor.execute("""SELECT updated_amount FROM teacher_payment_wallet
            where `teacher_id`=%s and Date(`last_update_ts`) 
            between %s and %s order by transaction_id desc""",
            (teacher_id,starting_date,tdate))
		duepaymentliveclass = cursor.fetchone()

		if duepaymentliveclass:
			due = duepaymentliveclass['updated_amount'] 
			
		else:
			due = 0

		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Teacher Performance Details",
                                "status": "success"
                                },
                 "responseList":{
                 				"CompletedCourses":CompletedCourses,
                 				"UpcomingCourses":UpcomingCourses,
                 				"CompletedClasses":CompletedClasses,
                 				"UpcomingClasses":UpcomingClasses,
                 				"CompletedClassesReg":CompletedClassesReg,
                 				"UpcomingClassesReg":UpcomingClassesReg,
                 				"EarnedAmount":payment,
                 				"DueAmount":due,
                 				"EarnedBonus":0,
                 				"DueBonus":0,
                 				}
                 }), status.HTTP_200_OK
