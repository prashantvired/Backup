import requests
import pymysql
import time
from flask import Flask, request, jsonify, json
from flask_api import status
from datetime import datetime,timedelta,date
from flask_cors import CORS, cross_origin
from flask import Blueprint
from flask_restplus import Api, Resource, fields
from database_connections import connect_recess

app = Flask(__name__)
cors = CORS(app)
chat_section = Blueprint('chat_section_api', __name__)
api = Api(chat_section,  title='Recess API',description='Recess API')
name_space = api.namespace('ChatController',description='Chat Section')


create_chat_session = api.model('create_voice_session', {
	"teacher_id":fields.Integer(required=True),
	"student_id":fields.Integer(required=True),
	"status":fields.String(),
	"session_description":fields.String()
	})

send_text = api.model('send_text', {
	"user_id":fields.Integer(required=True),
	"session_id":fields.Integer(required=True),
	"text":fields.String(),
	"filetype":fields.String()
	})

teacheradmin_chatsession = api.model('teacheradmin_chatsession', {
	"teacher_id":fields.Integer(),
	"admin_id":fields.Integer(),
	"flag":fields.String(),
	"status":fields.String(),
	"session_description":fields.String()
	})

@name_space.route("/StartChatSession")
class StartChatSession(Resource):
	@api.expect(create_chat_session)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()

		details = request.get_json()
		teacher_id = details.get('teacher_id')
		student_id = details.get('student_id')
		chatStatus = details.get('status')
		sessionDesc = details.get('session_description')

		cursor.execute("""SELECT cs.`session_id` FROM chat_session cs 
			inner join chat_teacher_mapping ctm on cs.`session_id` = 
			ctm.`session_id` WHERE cs.`student_id` = %s and 
			teacher_id=%s""",(student_id,teacher_id))
		session = cursor.fetchone()

		if session == None:
			cursor.execute("""SELECT user_id,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				imageurl FROM user_credential WHERE `user_id`=%s""",(teacher_id))
			teacherList = cursor.fetchone()
			details['teachername'] = teacherList['name']
			details['imageurl'] = teacherList['imageurl']

			chatInsertQuery = ("""INSERT INTO `chat_session`(`student_id`, 
				`status`, `session_description`) VALUES (%s,%s,%s)""")
			chatData = (student_id,chatStatus,sessionDesc)
			cursor.execute(chatInsertQuery,chatData)

			sessionId = cursor.lastrowid
			details['session_id'] = sessionId
			details['session_description'] = sessionDesc
			
			studntMapInsertQuery = ("""INSERT INTO `chat_teacher_mapping`(`session_id`, 
				`teacher_id`) VALUES (%s,%s)""")
			cursor.execute(studntMapInsertQuery,(sessionId,teacher_id))

		else:
			cursor.execute("""SELECT cs.`session_id`,session_description,
				status,teacher_id,student_id FROM chat_session cs 
				inner join chat_teacher_mapping ctm on cs.`session_id` = 
				ctm.`session_id` WHERE cs.`student_id`=%s and 
				teacher_id=%s""",(student_id,teacher_id))
			sessionDtls = cursor.fetchone()

			cursor.execute("""SELECT user_id,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
				imageurl FROM user_credential WHERE `user_id`=%s""",(teacher_id))
			teacherList = cursor.fetchone()
			details['teachername'] = teacherList['name']
			details['imageurl'] = teacherList['imageurl']

			details['session_id'] = sessionDtls['session_id']
			details['session_description'] = sessionDtls['session_description']
			details['teacher_id'] = sessionDtls['teacher_id']
			details['student_id'] = sessionDtls['student_id']
			details['status'] = sessionDtls['status']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Chat Details",
								"status": "success",
									},
				"responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/SendText")
class SendText(Resource):
	@api.expect(send_text)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()

		details = request.get_json()
		user_id = details.get('user_id')
		session_id = details.get('session_id')
		text = details.get('text')
		filetype = details.get('filetype')

		sendTextInsertQuery = ("""INSERT INTO `chat_session_mapping`(`session_id`,
		 `user_id`, `text`,`filetype`) VALUES (%s,%s,%s,%s)""")
		cursor.execute(sendTextInsertQuery,(session_id,user_id,text,filetype))

		TextId = cursor.lastrowid
		details['text_id'] = TextId

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Text Details",
								"status": "success",
									},
				"responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/getSessionDetailsByStudentId/<int:student_id>")
class getSessionDetailsByStudentId(Resource):
	def get(self,student_id):

		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT cs.`session_id`,session_description,
			teacher_id FROM chat_session cs 
			inner join chat_teacher_mapping ctm on cs.`session_id` = 
			ctm.`session_id` WHERE cs.`student_id` = %s""",(student_id))
		sessionDtls = cursor.fetchall()
		
		for sid,sess in enumerate(sessionDtls):
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
				teachername,imageurl FROM user_credential WHERE `user_id` = %s """,
				(sess.get('teacher_id')))
			teacherDtls = cursor.fetchone()
			sessionDtls[sid]['teachername'] = teacherDtls['teachername']
			sessionDtls[sid]['teacherimageurl'] = teacherDtls['imageurl']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Session Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#-------------------------------------------------------------#
@name_space.route("/getChatDetailsBySessionId/<int:session_id>")
class getChatDetailsBySessionId(Resource):
	def get(self,session_id):

		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `text` as msg,filetype,
			user_id FROM chat_session_mapping csm WHERE 
			`session_id`=%s order by last_update_ts Asc""",(session_id))
		sessionDtls = cursor.fetchall()
		
		for sid,sess in enumerate(sessionDtls):
			cursor.execute("""SELECT user_role FROM user_credential WHERE
			 `user_id` = %s """,(sess.get('user_id')))
			role = cursor.fetchone()

			if role['user_role'] == 'S1':

				cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
					studentname,imageurl FROM user_credential WHERE `user_id` = %s """,
					(sess.get('user_id')))
				studentDtls = cursor.fetchone()
				sessionDtls[sid]['studentname'] = studentDtls['studentname']

			else:
				cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
					teachername,imageurl FROM user_credential WHERE `user_id` = %s """,
					(sess.get('user_id')))
				teacherDtls = cursor.fetchone()
				sessionDtls[sid]['teachername'] = teacherDtls['teachername']
			
		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Chat Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#---------------------------------------------------------------#
@name_space.route("/getSessionDetailsByTeacherId/<int:teacher_id>")
class getSessionDetailsByTeacherId(Resource):
	def get(self,teacher_id):

		connection = connect_recess()
		cursor = connection.cursor()

		details = {}
		cursor.execute("""SELECT cs.`session_id`,session_description,
			student_id FROM chat_session cs 
			inner join chat_teacher_mapping ctm on cs.`session_id` = 
			ctm.`session_id` WHERE ctm.`teacher_id` = %s""",(teacher_id))
		sessionDtls = cursor.fetchall()
		
		for sid,sess in enumerate(sessionDtls):
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
				studentname,imageurl FROM user_credential WHERE `user_id` = %s """,
				(sess.get('student_id')))
			studentDtls = cursor.fetchone()
			sessionDtls[sid]['studentname'] = studentDtls['studentname']
			sessionDtls[sid]['studentimageurl'] = studentDtls['imageurl']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Session Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#-------------------------------------------------------------#
@name_space.route("/StartTeacherAdminChatSession")
class StartTeacherAdminChatSession(Resource):
	@api.expect(teacheradmin_chatsession)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()

		details = request.get_json()
		teacher_id = details.get('teacher_id')
		admin_id = details.get('admin_id')
		flag = details.get('flag')
		chatStatus = details.get('status')
		sessionDesc = details.get('session_description')

		if flag == 'admin':
			cursor.execute("""SELECT `session_id` FROM teacheradmin_chatsession tacs 
				WHERE `admin_id` = %s and `teacher_id`=%s""",(admin_id,teacher_id))
			session = cursor.fetchone()

			if session == None:
				cursor.execute("""SELECT user_id,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
					imageurl FROM user_credential WHERE `user_id`=%s""",(teacher_id))
				teacherList = cursor.fetchone()
				details['teachername'] = teacherList['name']
				details['imageurl'] = teacherList['imageurl']

				chatInsertQuery = ("""INSERT INTO `teacheradmin_chatsession`(`admin_id`,
					`teacher_id`,`flag`,`status`, `session_description`) VALUES (%s,%s,
					%s,%s,%s)""")
				chatData = (admin_id,teacher_id,'admin',chatStatus,sessionDesc)
				cursor.execute(chatInsertQuery,chatData)

				sessionId = cursor.lastrowid
				details['session_id'] = sessionId
				details['session_description'] = sessionDesc
				
			else:
				cursor.execute("""SELECT `session_id`,session_description,
					`flag`,status,`teacher_id`,`admin_id` FROM teacheradmin_chatsession tacs 
					WHERE `admin_id` = %s and `teacher_id`=%s""",(admin_id,teacher_id))
				sessionDtls = cursor.fetchone()

				cursor.execute("""SELECT user_id,CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as name,
					imageurl FROM user_credential WHERE `user_id`=%s""",(teacher_id))
				teacherList = cursor.fetchone()
				details['teachername'] = teacherList['name']
				details['imageurl'] = teacherList['imageurl']

				details['session_id'] = sessionDtls['session_id']
				details['session_description'] = sessionDtls['session_description']
				details['admin_id'] = sessionDtls['admin_id']
				details['teacher_id'] = sessionDtls['teacher_id']
				details['flag'] = sessionDtls['flag']
				details['status'] = sessionDtls['status']
		else:
			cursor.execute("""SELECT `session_id` FROM teacheradmin_chatsession tacs 
				WHERE `teacher_id`=%s and `admin_id`=%s""",(teacher_id,admin_id))
			session = cursor.fetchone()

			if session == None:
				cursor.execute("""SELECT admin_id,name,imageurl FROM admin_dtls 
					WHERE `admin_id`=%s""",(admin_id))
				adminList = cursor.fetchone()
				details['adminname'] = adminList['name']
				details['imageurl'] = adminList['imageurl']

				chatInsertQuery = ("""INSERT INTO `teacheradmin_chatsession`(`admin_id`,
					`teacher_id`,`flag`,`status`, `session_description`) VALUES (%s,%s,
					%s,%s,%s)""")
				chatData = (admin_id,teacher_id,'teacher',chatStatus,sessionDesc)
				cursor.execute(chatInsertQuery,chatData)

				sessionId = cursor.lastrowid
				details['session_id'] = sessionId
				details['session_description'] = sessionDesc
				
			else:
				cursor.execute("""SELECT `session_id`,session_description,
					`flag`,status,`teacher_id`,`admin_id` FROM teacheradmin_chatsession tacs 
					WHERE `teacher_id` = %s and `admin_id`=%s""",(teacher_id,admin_id))
				sessionDtls = cursor.fetchone()

				cursor.execute("""SELECT admin_id,name,imageurl FROM admin_dtls 
					WHERE `admin_id`=%s""",(admin_id))
				adminList = cursor.fetchone()
				details['adminname'] = adminList['name']
				details['imageurl'] = adminList['imageurl']

				details['session_id'] = sessionDtls['session_id']
				details['session_description'] = sessionDtls['session_description']
				details['teacher_id'] = sessionDtls['teacher_id']
				details['admin_id'] = sessionDtls['admin_id']
				details['flag'] = sessionDtls['flag']
				details['status'] = sessionDtls['status']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Teacher admin Chat Details",
								"status": "success",
									},
				"responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/TeacherAdminResponse")
class TeacherAdminResponse(Resource):
	@api.expect(send_text)
	def post(self):
		connection = connect_recess()
		cursor = connection.cursor()

		details = request.get_json()
		user_id = details.get('user_id')
		session_id = details.get('session_id')
		text = details.get('text')
		filetype = details.get('filetype')

		sendTextInsertQuery = ("""INSERT INTO `teacheradmin_chatsession_mapping`(`session_id`,
		 `user_id`, `text`,`filetype`) VALUES (%s,%s,%s,%s)""")
		cursor.execute(sendTextInsertQuery,(session_id,user_id,text,filetype))

		TextId = cursor.lastrowid
		details['text_id'] = TextId

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Text Details",
								"status": "success",
									},
				"responseList":details}), status.HTTP_200_OK

#------------------------------------------------------------------#
@name_space.route("/getSessionDetailsByAdminId/<int:admin_id>")
class getSessionDetailsByAdminId(Resource):
	def get(self,admin_id):

		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `session_id`,session_description,
			`teacher_id` FROM teacheradmin_chatsession WHERE `admin_id`=%s
			and flag='admin'""",(admin_id))
		sessionDtls = cursor.fetchall()
		
		for sid,sess in enumerate(sessionDtls):
			cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
				teachername,imageurl FROM user_credential WHERE `user_id` = %s """,
				(sess.get('teacher_id')))
			teacherDtls = cursor.fetchone()
			sessionDtls[sid]['teachername'] = teacherDtls['teachername']
			sessionDtls[sid]['teacherimageurl'] = teacherDtls['imageurl']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Session Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#-------------------------------------------------------------#
@name_space.route("/TeacherAdminChatDetailsBySessionId/<int:session_id>")
class TeacherAdminChatDetailsBySessionId(Resource):
	def get(self,session_id):

		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT admin_id,flag,teacher_id FROM `teacheradmin_chatsession` where
			`session_id`=%s""",(session_id))
		chat_session = cursor.fetchone()

		if chat_session['flag'] == 'admin':
			
			cursor.execute("""SELECT `text` as msg,filetype,
				user_id FROM teacheradmin_chatsession_mapping WHERE 
				`session_id`=%s order by last_update_ts Asc""",(session_id))
			sessionDtls = cursor.fetchall()
			if sessionDtls:
				for sid,sess in enumerate(sessionDtls):
					if sess.get('user_id') == chat_session['admin_id']:
						cursor.execute("""SELECT admin_id,name,imageurl FROM admin_dtls 
							WHERE `admin_id`=%s""",(chat_session['admin_id']))
						adminDtls = cursor.fetchone()
						
						sessionDtls[sid]['adminname'] = adminDtls['name']

					else:
						cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
							teachername,imageurl FROM user_credential WHERE `user_id` = %s """,
							(sess.get('user_id')))
						teacherDtls = cursor.fetchone()
						sessionDtls[sid]['teachername'] = teacherDtls['teachername']
		else:
			cursor.execute("""SELECT `text` as msg,filetype,
				user_id FROM teacheradmin_chatsession_mapping WHERE 
				`session_id`=%s order by last_update_ts Asc""",(session_id))
			sessionDtls = cursor.fetchall()
			if sessionDtls:
				for sid,sess in enumerate(sessionDtls):
					if sess.get('user_id') == chat_session['teacher_id']:
						cursor.execute("""SELECT CONCAT(first_name , ' ' , middle_name , ' ' , last_name)as 
							teachername,imageurl FROM user_credential WHERE `user_id` = %s """,
							(sess.get('user_id')))
						teacherDtls = cursor.fetchone()
						sessionDtls[sid]['teachername'] = teacherDtls['teachername']

					else:
						cursor.execute("""SELECT admin_id,name,imageurl FROM admin_dtls 
							WHERE `admin_id`=%s""",(chat_session['admin_id']))
						adminDtls = cursor.fetchone()
						
						sessionDtls[sid]['adminname'] = adminDtls['name']
					
		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Chat Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#---------------------------------------------------------------#
@name_space.route("/SessionDetailsByTeacherId/<int:teacher_id>")
class SessionDetailsByTeacherId(Resource):
	def get(self,teacher_id):

		connection = connect_recess()
		cursor = connection.cursor()

		cursor.execute("""SELECT `session_id`,session_description,
			`admin_id` FROM teacheradmin_chatsession WHERE `teacher_id`=%s
			and flag='teacher'""",(teacher_id))
		sessionDtls = cursor.fetchall()
		
		for sid,sess in enumerate(sessionDtls):
			cursor.execute("""SELECT admin_id,name,imageurl FROM admin_dtls 
				WHERE `admin_id`=%s """,(sess.get('admin_id')))
			adminDtls = cursor.fetchone()
			sessionDtls[sid]['adminname'] = adminDtls['name']
			sessionDtls[sid]['adminimageurl'] = adminDtls['imageurl']

		connection.commit()
		cursor.close()

		return ({"attributes": {"status_desc": "Session Details",
								"status": "success",
									},
				"responseList":sessionDtls}), status.HTTP_200_OK

#-------------------------------------------------------------#