import pymysql
from flask import Flask, request, jsonify, json
from flask_api import status
from datetime import datetime,timedelta,date
from flask_cors import CORS, cross_origin
from flask import Blueprint
from flask_restplus import Api, Resource, fields
from database_connections import connect_recess
import requests
import os
from instamojoConfig import CLIENT_ID,CLIENT_SECRET,referrer

app = Flask(__name__)
cors = CORS(app)

instamojo_payments = Blueprint('instamojo_payments_api', __name__)
api = Api(instamojo_payments,  title='Recess API',description='Recess API')
name_space = api.namespace('paymentController',description='Instamojo')


create_payment_link_model = api.model('create_payment_link_model', {
	"amount":fields.Integer(),
	"purpose":fields.String(),
	"buyer_name":fields.String(),
	"email":fields.String(),
	"phone":fields.String(),
	"price_id":fields.Integer()
	})

ask_for_fees_model = api.model('ask_for_fees_model', {
	"amount":fields.Integer(),
	"purpose":fields.String(),
	"price_id":fields.String(),
	"student_id":fields.Integer()
	})

razorpay_model = api.model('razorpay_model', {
	"amount":fields.Integer(),
	"purpose":fields.String(),
	"user_id":fields.Integer(),
	"payment_status":fields.String(),
	"payment_id":fields.String(),
	"remarks":fields.String()
	})


MOJO_TEST_URL = 'https://test.instamojo.com/'

MOJO_BASE_URL = 'https://api.instamojo.com/'

BASE_URL = "http://ec2-18-191-151-105.us-east-2.compute.amazonaws.com/flaskapp/"

# BASE_URL = "http://127.0.0.1:5000/"

#------------------------------------------------------#
@name_space.route("/RazorPaymentDetails")
class RazorPaymentDetails(Resource):
	@api.expect(razorpay_model)
	def post(self):
		
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		amount = details.get('amount')
		purpose = details.get('purpose')
		user_id = details.get('user_id')
		payment_status = details.get('payment_status') 
		payment_id = details.get('payment_id') 
		remarks = details.get('remarks')
		
		paymentQuery = ("""INSERT INTO `razorpay_payment_dtls`(`user_id`,
			purpose, amount,`payment_status`,remarks) VALUES (%s,
			%s,%s,%s,%s)""")
		
		paymentData = cursor.execute(paymentQuery,(user_id,
			purpose, amount,payment_status,remarks))

		if paymentData:
			request_id = cursor.lastrowid
			details['request_id'] = request_id

			cursor.execute("""SELECT `previous_balance`,`added_balance`,
				`updated_balance` FROM `student_wallet_transaction` WHERE 
				`student_id` = %s ORDER BY `transaction_id` DESC""",(user_id))
			wallettrnsDtls = cursor.fetchone()

			previous_amount = wallettrnsDtls.get('updated_balance')

			cursor.execute("""SELECT no_of_liveclass FROM liveclass_price_dtls WHERE 
				`total_amount`=%s""",(amount))	
			noliveclass = cursor.fetchone()
			
			if noliveclass['no_of_liveclass'] == 'Single Class':
				added_amount = 1
			elif noliveclass['no_of_liveclass'] == '5 Classes':
				added_amount = 5
			elif noliveclass['no_of_liveclass'] == '10 Classes':
				added_amount = 10
			elif noliveclass['no_of_liveclass'] == '15 Classes':
				added_amount = 15
			else:
				added_amount = 'unlimited'

			if previous_amount == 'unlimited':
				update_amount = 'unlimited'
			elif added_amount == 'unlimited':
				update_amount = added_amount

			else:
				update_amount = int(previous_amount) + added_amount

			transQuery = ("""INSERT INTO `student_wallet_transaction`(`student_id`,
				`previous_balance`,`added_balance`,`updated_balance`) VALUES (%s,
				%s,%s,%s)""")
			
			transData = cursor.execute(transQuery,(user_id,previous_amount,
				added_amount,update_amount))

			updateWallet = ("""UPDATE `student_wallet` SET 
				`update_amount`=%s where `student_id` = %s""")
			cursor.execute(updateWallet,(update_amount,user_id))

			msg = 'Payment Details Added'

		else:
			msg = 'Payment Details Added'
			
		connection.commit()
		cursor.close()

		return ({"attributes": {
								"status_desc": "Razor Pay Payment Details",
								"status": "success",
								"msg": msg
								},
			"responseList": details}), status.HTTP_200_OK
#------------------------------------------------------#
@name_space.route("/createPaymentRequest")
class createPaymentRequest(Resource):
	@api.expect(create_payment_link_model)
	def post(self):
		
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		client_id = 'xSK1kAqi4WI5AreACdp2n3DO0JE50DCK4X27E5IF'
		client_secret = 'cUp1myysReRLYIHMq9bMESDckDrP00qS9go3Ti4th3C1UQKHZyJlBoZII6idi74Ki1EviYLDTlTEAEpe9sEnztMBrMZ1nSP36utmSTYjKLL0nzgYL7ATHcYUPN1tjynh'
		referrer_id = 'creamsonmyelsa'

		payload = {"grant_type": "client_credentials",
					"client_id": client_id,
					"client_secret": client_secret}
		# print(payload)

		authResponse = requests.post(MOJO_BASE_URL+"oauth2/token/",
			data=payload).json()
		# print(authResponse)

		accesstoken = authResponse.get('access_token')

		headers = {"Authorization": "Bearer "+accesstoken}

		details['redirect_url'] = 'http://creamsonservices.com/recessinstamojo_test.php'
		details['allow_repeated_payments'] = False
		details['send_email'] = False
		details['send_sms'] = True
		priceId = details.get('price_id',None)
		details.pop('user_id',None)
		# transactionId = details.get('transaction_id',None)
		# details.pop('transaction_id',None)
		mojoResponse = requests.post(MOJO_BASE_URL+"v2/payment_requests/",
			data=details, headers=headers)

		statusCode = mojoResponse.status_code
		# print(statusCode)
		response = mojoResponse.json()
		# print(response)

		if statusCode == 201:

			mojoResInsertQuery = ("""INSERT INTO `instamojo_payment_request`(`instamojo_request_id`, 
				`phone`, `email`, `buyer_name`, `amount`, `purpose`, `status`, `send_sms`, 
				`send_email`, `sms_status`, `email_status`, `shorturl`, `longurl`, 
				`redirect_url`, `webhook`, `scheduled_at`, `expires_at`, `allow_repeated_payments`, 
				`mark_fulfilled`, `customer_id`, `created_at`, `modified_at`, `resource_uri`, 
				`remarks`, `price_id`,`transaction_id`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
				%s,%s,%s,%s,%s,%s,%s,%s)""")

			created_at = datetime.strptime(response.get('created_at'),'%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d %H:%M:%S')
			modified_at = datetime.strptime(response.get('modified_at'),'%Y-%m-%dT%H:%M:%S.%fZ').strftime('%Y-%m-%d %H:%M:%S')

			mojoData = (response.get('id'),details.get('phone'),response.get('email'),
				response.get('buyer_name'),response.get('amount'),response.get('purpose'),
				response.get('status'),response.get('send_sms'),response.get('send_email'),
				response.get('sms_status'),response.get('email_status'),response.get('shorturl'),
				response.get('longurl'),response.get('redirect_url'),response.get('webhook'),
				response.get('scheduled_at'),response.get('expires_at'),response.get('allow_repeated_payments'),
				response.get('mark_fulfilled'),response.get('customer_id'),
				created_at,modified_at,response.get('resource_uri'),response.get('remarks'),priceId,'')
			cursor.execute(mojoResInsertQuery,mojoData)

			requestId = cursor.lastrowid
			response['paymentRequestId'] = requestId

			

			msg = 'Payment Link Created'
		else:
			response = {}
			msg = 'No matching credentials'
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Instamojo payment request Details",
								"status": "success",
								"msg":msg},
				"responseList": response}), status.HTTP_200_OK



@name_space.route("/askForLiveClassFess")
class askForFessByTeacher(Resource):
	@api.expect(ask_for_fees_model)
	def post(self):
		
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()


		URL = BASE_URL + "instamojo_payments/paymentController/createPaymentRequest"

		headers = {'Content-type':'application/json', 'Accept':'application/json'}

		amount = details.get('amount')
		purpose = details.get('purpose')
		price_id = details.get('price_id')
		student_id = details.get('student_id')
		
		cursor.execute("""SELECT concat(`first_name`," ",`last_name`) as name,`phone_no` as phone 
			FROM `user_credential` WHERE `user_id` = %s""",(student_id))

		student = cursor.fetchone()

		if student:
			student_name = student['name']
			student_phone = student['phone']

			payload = {"amount":amount,
						"purpose":purpose,
						"buyer_name":student_name,
						"phone":student_phone,
						"price_id":price_id}
			
			mojoResponse = requests.post(URL,data=json.dumps(payload), headers=headers).json()

			# print(mojoResponse)
			if mojoResponse.get('attributes').get('msg') == 'Payment Link Created':

				paymentStudentMapQuery = ("""INSERT INTO `instamojo_payment_student_mapping`(
					`request_id`, `student_id`, `status`) VALUES (%s,%s,%s)""")
				responseList = mojoResponse.get('responseList')
				mapData = (responseList.get('paymentRequestId'),student_id,responseList.get('status'))

				cursor.execute(paymentStudentMapQuery,mapData)
			else:
				[]
		
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Instamojo Payment Initiation Details",
							"status": "success"},
			"responseList": mojoResponse}), status.HTTP_200_OK



@name_space.route("/updatePaymentDetails/<string:payment_id>/<string:payment_status>/<string:payment_request_id>")
class updatePaymentDetails(Resource):
	def put(self,payment_id,payment_status,payment_request_id):
		
		connection = connect_recess()
		cursor = connection.cursor()
		details = request.get_json()

		update_status = 'Complete'
		if payment_status == 'Credit':

			updatePaymentQuery = ("""UPDATE `instamojo_payment_request` SET  
				`payment_status` = %s,`payment_id`= %s, `status` = %s WHERE `instamojo_request_id`= %s""")

			paymentData = (payment_status,payment_id,update_status,payment_request_id)

			cursor.execute(updatePaymentQuery,paymentData)

			cursor.execute("""SELECT `request_id`,`price_id` FROM `instamojo_payment_request` 
				WHERE `instamojo_request_id` = %s""",(payment_request_id))
			reqDtls = cursor.fetchone()

			reqId = reqDtls.get('request_id')	
			priceId = reqDtls.get('price_id')

			cursor.execute("""SELECT `student_id` FROM `instamojo_payment_student_mapping`
			 	WHERE `request_id` = %s""",(reqId))
			preqDtls = cursor.fetchone()

			student_id = preqDtls.get('student_id')	
			
			updateStudentStatus = ("""UPDATE `instamojo_payment_student_mapping` SET 
				`status` = %s where `request_id` = %s""")
			cursor.execute(updateStudentStatus,(update_status,reqId))

			cursor.execute("""SELECT `previous_amount`,`added_amount`,`update_amount` FROM 
				`student_wallet` WHERE `student_id` = %s""",(student_id))
			walletDtls = cursor.fetchone()

			previous_amount = walletDtls.get('previous_amount')	
			if priceId == 1:
				added_amount = 1
			elif priceId == 2:
				added_amount = 5
			elif priceId == 3:
				added_amount = 10
			elif priceId == 4:
				added_amount = 15
			else:
				added_amount = 'unlimited'

			if previous_amount == 'unlimited':
				update_amount = 'unlimited'
			else:
				update_amount = int(previous_amount) + added_amount

			updateWallet = ("""UPDATE `student_wallet` SET `previous_amount`=%s,
				`added_amount`=%s,`update_amount`=%s where `student_id` = %s""")
			cursor.execute(updateWallet,(previous_amount,added_amount,update_amount,student_id))

			msg = 'Payment Details Updated'
		else:
			msg = 'Payment Details Not Updated'
			
		connection.commit()
		cursor.close()
		return ({"attributes": {"status_desc": "Instamojo Payment Details",
							"status": "success"},
			"responseList": msg}), status.HTTP_200_OK

